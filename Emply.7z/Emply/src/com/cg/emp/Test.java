package com.cg.emp;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
public class Test {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
	
		while(true)
		{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("Emply");
			EntityManager em=emf.createEntityManager();
			em.getTransaction().begin();
			System.out.println("Enter your choice:\n  1.Add\n 2.View All \n 3.Update\n 4.Delete \n 5.Search by Id\n 6.exit");
			int n=s.nextInt();
			switch(n)
			{
			case 1:
				
				
				Employee e=new Employee();
				System.out.println("Enter Employee name");
				String name =s.next();
				e.setName(name);
				System.out.println("Enter Employee salary");
				double sal=s.nextDouble();
				e.setSalary(sal);
				em.persist(e);
				
				System.out.println(" Details Added");
				break;
			case 2:
				
				Query q=em.createQuery("select l2 from Employee l2");
				List<Employee> list =q.getResultList();
				for(Employee lib:list)
				{
					System.out.println("==============================================");
					System.out.println("Id: "+lib.getId());
					System.out.println("Employee Name: "+lib.getName());
					System.out.println("Employee Salary: "+lib.getSalary());
				}
				
				break;
			case 3:
				System.out.println("Enter Employee id to update employee details :");
				int id=s.nextInt();
				Employee l1=em.find(Employee.class, id);
				
				if(l1!=null)
				{
					System.out.println("Enter Employee Name :");
				  l1.setName(s.next());
				  System.out.println("Enter Employee Salary :");
				  l1.setSalary(s.nextDouble());
				  em.persist(l1);
				  System.out.println("Updated");
				}
				else
					System.out.println("Employee does not exist");
				
				break;
			case 4:
			
				System.out.println("Enter Employee id to delete:");
				int i=s.nextInt();
				Employee l=em.find(Employee.class, i);
				em.remove(l); 
				System.out.println("deleted");
				break;
			case 5:
			
				System.out.println("Enter Employee id to search :");
				int search=s.nextInt();
				Employee m=em.find(Employee.class, search);
				System.out.println("Empoyee Name: "+m.getName());
				System.out.println("Employee Salary: "+m.getSalary());
				
				break;
			case 6:
				System.exit(0);
				break;
			
			}
			em.getTransaction().commit();
			em.close();
			emf.close();
		}
	}

}
