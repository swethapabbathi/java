package com.cg.emp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@TableGenerator(name="tab_seq1",initialValue=1,allocationSize=1)
@Table(name="employee_details")
public class Employee{
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE,generator="tab_seq1")
	private int id;
	@Column(name="ename")
	private String name;
	@Column(name="esal")
	private double salary;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	

}
