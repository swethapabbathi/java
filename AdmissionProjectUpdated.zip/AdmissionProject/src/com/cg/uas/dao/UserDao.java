package com.cg.uas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;

public class UserDao 
{
	Connection con=null;
	PreparedStatement ps=null;
	
	public Connection getConnection()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user="system";
			String pass="Capgemini123";
			con =DriverManager.getConnection(url,user,pass);
			return con;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
		
	}
	public boolean validate(String username ,String password)
	{
		try
		{
		con =getConnection();
		String sql="select *from Users where password=?";
		ps=con.prepareStatement(sql);
		ps.setString(1,password);
		ResultSet rs=ps.executeQuery();
		return rs.next();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
		
	}
	public int add(String username,String password,String role)
	{
		con =getConnection();
		String sql="insert into users values(?,?,?)";
		
		try
		{
			ps=con.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ps.setString(3, role);
		
			int n=ps.executeUpdate();
			return n;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
	}
	
	 private static java.sql.Date convertUtilToSql(java.util.Date uDate)

	 {
              java.sql.Date sDate = new java.sql.Date(uDate.getTime());
              return sDate;
	 }
	public int addProgram(String spid, String pname, String location,
			String startdate1, String enddate1, String session) throws SQLException  {
		con =getConnection();
		
		
		String sql="select *from Programs_Offered where ProgramName=?";
		ps=con.prepareStatement(sql);
		ps.setString(1, pname);
		ResultSet rs=ps.executeQuery();
		if (rs.next())
		{
			String sql1="insert into Programs_Scheduled values(?,?,?,?,?,?)";
	
		try
		{
			ps=con.prepareStatement(sql1);
			ps.setString(1, spid);
			ps.setString(2, pname);
			ps.setString(3, location);
			/*String std[] = startdate1.split("-");
			int y = Integer.parseInt(std[0]);
			int m = Integer.parseInt(std[1]);
			int d = Integer.parseInt(std[2]);*/
			
			  java.util.Date date1=new SimpleDateFormat("yyyy-MM-dd").parse(startdate1);  
		      java.sql.Date sDate1 = convertUtilToSql(date1);
			
			ps.setDate(4, sDate1);
			

			/*String std1[] = enddate1.split("-");
			int y1 = Integer.parseInt(std1[0]);
			int m1 = Integer.parseInt(std1[1]);
			int d1 = Integer.parseInt(std1[2]);
			ps.setDate(5, new java.sql.Date(y1, m1, d1));
*/		
			java.util.Date date2=new SimpleDateFormat("yyyy-MM-dd").parse(enddate1);  
			java.sql.Date sDate2 = convertUtilToSql(date2);
			ps.setDate(5, sDate2);
			
			ps.setString(6, session);
			int n=ps.executeUpdate();
			return n;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		}
		else
			return 0;
	}
	public int addProgramsOffered(String pname, String description,
			String eligibility, String duration, String certificate) {
		
		con =getConnection();
		String sql="insert into Programs_Offered values(?,?,?,?,?)";
		
		try
		{
			ps=con.prepareStatement(sql);
			ps.setString(1, pname);
			ps.setString(2, description);
			ps.setString(3, eligibility);
			ps.setString(4, duration);
			ps.setString(5, certificate);
			
		int n=ps.executeUpdate();
			return n;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	public long addApplicant(String name, String dob, String hq, String marks,
			String goals,String mail, String programid) {
		con =getConnection();
		String sql="insert into  Application(Application_id, full_name, date_of_birth, highest_qualification, marks_obtained, goals, email_id, Scheduled_program_id) values(appId_seq.nextval,?,?,?,?,?,?,?)";
		long ApplicantId=0;
		try
		{
			ps=con.prepareStatement(sql);
			ps.setString(1, name);
			String std[] = dob.split("-");
			int y = Integer.parseInt(std[0]);
			int m = Integer.parseInt(std[1]);
			int d = Integer.parseInt(std[2]);
			ps.setDate(2, new java.sql.Date(y, m, d));

			ps.setString(3,hq);
			ps.setString(4,marks);
			ps.setString(5, goals);
			ps.setString(6, mail);
			ps.setString(7, programid);
			int n=ps.executeUpdate();
			
			ps=con.prepareStatement("select max(Application_id) from Application");
			ResultSet resultSet = ps.executeQuery();
			resultSet.next();
			ApplicantId = resultSet.getLong(1);
			return ApplicantId;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	public String checkStatus(String appid) {
		
		con =getConnection();
		String sql="select status from application where Application_id=?";
		
		try
		{
			ps=con.prepareStatement(sql);
			ps.setString(1, appid);
			ResultSet rs=ps.executeQuery();
			rs.next();
			String 	ApplicantStatus = rs.getString(1);
			return ApplicantStatus;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return null;
	}
	public Date checkStatus1(String appid) {
		
		con =getConnection();
		String sql="select   Date_Of_Interview from application where Application_id=?";
		
		try
		{
			ps=con.prepareStatement(sql);
			ps.setString(1, appid);
			ResultSet rs=ps.executeQuery();
			rs.next();
			Date date = rs.getDate(1);
			return date;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return null;
	}
	

}
