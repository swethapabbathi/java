package Dynamicpol;
class p
{
	void m1(){
		System.out.println("parent");
	}
}
class c extends p
{
	void m2(){
		System.out.println("child");
	}
}
public class Dynamic 
{
	public static void main(String args[])
	{
		p p1=new c();
		c c1=(c)p1;
		c1.m2();
	}
}
