package com.capgemini.tcc.service;

import java.util.List;

import com.capgemini.tcc.been.PatientBean;
import com.capgemini.tcc.exceptions.TakeCareException;

public interface IPatientService {

	boolean validateDetails(PatientBean patient) throws TakeCareException;

	

	int addPatientDetails(PatientBean patient) throws TakeCareException;



	PatientBean getPatientDetails(int patientId)throws TakeCareException;

	
}
