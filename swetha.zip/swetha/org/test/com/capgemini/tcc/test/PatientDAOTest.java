package com.capgemini.tcc.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.tcc.been.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exceptions.TakeCareException;


public class PatientDAOTest {

	IPatientDAO dao = null;

	@Before
	public void setUp() {
		dao = new PatientDAO();
	}

	@After
	public void tearDown() {
		dao = null;
	}

	@Test
	public void testAddDetails() {

		PatientBean m = new PatientBean();
		m.setPatientName("Vinithh");
		m.setAge(44);
		m.setPhone(1234536789);
		m.setDescription("headache person");
	

		try {
			Integer id = dao.addPatientDetails(m);
			assertNotNull(id);

		} catch (TakeCareException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testGetDetails()
	{

		PatientBean m = null  ;
		IPatientDAO dao=new PatientDAO();
		try {
			m=dao.getPatientDetails(1001);
		} catch (TakeCareException e) {
			
		}
	
		
		assertEquals("Swethaaa",m.getPatientName());

	}

}
