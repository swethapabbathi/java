package com.capgemini.contactbook.service;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceImpl implements ContactBookService{

	
	ContactBookDao dao=new ContactBookDaoImpl();
	/**
	 * Method name : isValidEnquiry
	 * Purpose     : It takes input as EnquiryBean object and returns True if all fields are correct
	 * Input       : EnquiryBean object
	 * Output      : boolean true or false
	 * PublishedDate: 29/10/18
	 * Author       :Capgemini
	 */

	@Override
	public boolean isValidEnquiry(EnquiryBean e) throws ContactBookException 
	{
		List<String> list = new ArrayList<>();
		boolean flag = false;

		if (!validateFirstName(e.getfName()))
			{
			list.add(" First name should start with capital letter only  & length should be greater than 4 and less than 20");
		}
		if (!validateLastName(e.getlName()))
		{
			list.add(" Last name length should be between 5 to 20 only ");
		}
		if (!validateContacNo(e.getContactNo())) {
			list.add("Contact number should be exactly 10 digits");
		}
		if(!validatePrefferedLocation(e.getpLocation()))
		{
			list.add("Location name should have atleast 4 charahters ");
			
		}
		if(!validatePrefferedDomain(e.getpDomain()))
		{
			list.add("Domain name should have atleast 4 charahters ");
			
		}
		
		if (!list.isEmpty()) {
			flag = false;
			throw new ContactBookException(list + "");
		} else {
			flag = true;
		}
		return flag;
	}
	/**
	 * Method Name     : validateFirstName
	 * input 		   :  string 
	 * Return          :  true or false
	 * PublishedDate   : 29/10/18
	 * Author          :  Capgemini
	 */
	
	public boolean validateFirstName(String fName) {

		String fnameRegEx = "[A-Z]{1}[a-zA-Z]{4,20}";
		Pattern pattern = Pattern.compile(fnameRegEx);
		Matcher matcher = pattern.matcher(fName);
		return matcher.matches();
	}
	/**
	 * Method Name     : validateLastName
	 * input 		   :  string 
	 * Return          :  true or false
	 * PublishedDate   : 29/10/18
	 * Author          :  Capgemini
	 */
	public boolean validateLastName(String lName) {

		String lnameRegEx = "[a-zA-Z]{5,20}";
		Pattern pattern = Pattern.compile(lnameRegEx);
		Matcher matcher = pattern.matcher(lName);
		return matcher.matches();
	}
	
	public boolean validateContacNo(String contactNo) {

		String phoneregEx = "[0-9]{10}";
		Pattern pattern = Pattern.compile(phoneregEx);
		Matcher matcher = pattern.matcher(contactNo);
		return matcher.matches();
	}

	public boolean validatePrefferedLocation(String pLocation) {

		String locationRegEx = "[a-zA-Z]{4,}";
		Pattern pattern = Pattern.compile(locationRegEx);
		Matcher matcher = pattern.matcher(pLocation);
		return matcher.matches();
	}
	public boolean validatePrefferedDomain(String pDomain)
	{
		String domainRegEx = "[a-zA-Z]{4,}";
		Pattern pattern = Pattern.compile(domainRegEx);
		Matcher matcher = pattern.matcher(pDomain);
		return matcher.matches();
	}
	
	/**
	 * Method Name     : addEnquiry
	 * input 		   :  EnquiryBean object
	 * Return          :   int type id
	 * PublishedDate   : 29/10/18
	 * Author          :  Capgemini
	 */
	public int addEnquiry(EnquiryBean en) throws ContactBookException {
		
		return dao.addEnquiry(en);
	}
	

	/**
	 * Method Name     :  getEnquiryDetails
	 * input 		   :  EnquiryID
	 * Return          :  EnquiryBean object
	 * PublishedDate   : 29/10/18
	 * Author          :  Capgemini
	 */
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException {
		
		return dao.getEnquiryDetails(EnquiryID);
	}
	
}
