package com.capgemini.contactbook.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.igate.contactbook.bean.EnquiryBean;
 import com.capgemini.contactbook.exception.*;


public class Client {
	static Logger logger = Logger.getLogger(Client.class);

	public static void main(String[] args)
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j file loaded...");
		logger.info("Inside the main method.......");
		
		ContactBookService service = new ContactBookServiceImpl();

		Scanner scanner = new Scanner(System.in);

		// patientService service = new patientServiceImpl();
		while (true)

		{
			System.out
					.println("***********Global Recruitments**********");
			System.out
					.println("_____________________________________________________");
			System.out.println("Choose an operation");
			System.out.println("1. Enter enquiry details");
			System.out.println("2. View enquiry details on ID");
			System.out.println("0. Exit");
			System.out.println("Please enter a choice:");
			int option=0;
			try
			{
			 option = scanner.nextInt();//asking the user to enter his right choice from the menu
			}
			catch(InputMismatchException e)
			{
				System.out.println("Enter only digits for option:");
			}

			switch (option) {

			case 1:
				scanner.nextLine();
				EnquiryBean bean = new EnquiryBean();
				//adding the person details to the Enquiry table in the database
				
				System.out.println("Enter First Name:");
				String firstname = scanner.nextLine();
				bean.setfName(firstname);
				
				System.out.println("Enter Last Name:");
				
				 String lastname = scanner.nextLine();
				 bean.setlName(lastname);
				
				 System.out.println("Enter Contact Number:");
				 String contactno=scanner.nextLine();
				 
				bean.setContactNo(contactno);
				System.out.println("Enter Preferred Domain:");
				String pdomain=scanner.nextLine();
				bean.setpDomain(pdomain);

				System.out.println("Enter Prefered Location");
				String plocation=scanner.nextLine();
				bean.setpLocation(plocation);

				try {

					boolean result = service.isValidEnquiry(bean);//checking whether the enter details are correct or not

					if (result) {
						int id = service.addEnquiry(bean);
						System.out.println("Thank you: "+bean.getfName()+" "+bean.getlName()+ " your unique id is:"
										+id);
					}

				} catch (ContactBookException e) {
					System.err.println(e.getMessage());
				}

				break;
			case 2:
				System.out.println("Enter the enquiry no");
				//Asking the user to enter the enquiry id on which he want to see the details of the person
				int id=0;
				try{
					id = scanner.nextInt();
				}
				catch(InputMismatchException e)
				{
					System.out.println("enter only digits");
				}
				
				
				
				EnquiryBean eb;
				try {
					eb = service.getEnquiryDetails(id);
					System.out.println(eb);

				} catch (ContactBookException e) {

					System.err.println(e.getMessage());
				}
				break;
			case 0:
				System.out.println("Thank you selecting us!!");
				System.exit(0);
				break;

			default:
				break;
			}

		}

	
		

	}

}
