package com.capgemini.contactbook.dao.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.igate.contactbook.bean.EnquiryBean;


public class ContactBookDaoImplTest {

	ContactBookDao dao = null;
	ContactBookService service=null;

	@Before
	public void setUp() {
		dao = new ContactBookDaoImpl();
		service= new ContactBookServiceImpl();
	}

	@After
	public void tearDown() {
		dao = null;
	}
	/**
	 * Method          : testAddEnquiry
	 * input           :  void
	 * return          :  void
	 * PublishedDate   : 29/10/18
	 * Author          :  Capgemini
	 */
	@Test
	public void testAddEnquiry() {

		EnquiryBean m = new EnquiryBean();
		m.setfName("Sahasra");
		m.setlName("vanga");
		m.setContactNo("1234567890");
		m.setpDomain("html");
		m.setpLocation("hyderabad");

		try {
			boolean flag=false;
			flag=service.isValidEnquiry(m);
			Integer id=0;
			if(flag)
			{
				id = dao.addEnquiry(m);//adding sahasra details to the enquiry table in the database
			}
			assertNotNull(id);//Checking whether the id is generated or not

		} catch (ContactBookException e) {
			System.out.println("Enter correct values");
		}

	}
	/**
	 * Method          : testGetDetails
	 * input           :  void
	 * return          :  void
	 * PublishedDate   : 29/10/18
	 * Author          :  Capgemini
	 */

	@Test
	public void testGetDetails()
	{

		EnquiryBean m = null  ;
		ContactBookDao dao=new ContactBookDaoImpl();
		try {
			m=dao.getEnquiryDetails(1001);
		} catch (ContactBookException e) {
			e.printStackTrace();
		}	
		assertEquals("Nakshatra",m.getfName());//Testing whether the 1001 id holder is Nakshatra or not

	}

}
