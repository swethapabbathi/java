package com.capgemini.emp.ui;

import java.util.Scanner;
import java.util.regex.Pattern;

public class MainClass
{

	public static void main(String[] args)
	{
		Validation v=new Validation();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter phone number");
		while(true)
		{
			String n=s.next();
			if(v.checkPhoneno(n))
				break;
			System.out.println("Enter valid phone number...");
		}
		System.out.println("Enter your Name :");
		while(true)
		{
			String n1=s.next();
			if(v.checkName(n1))
				break;
			System.out.println("Enter valid Name...");
		}
		System.out.println("Enter your PAN Number :");
		while(true)
		{
			String n2=s.next();
			if(v.checkPAN(n2))
				break;
			System.out.println("Enter valid PAN Number ...");
		}
		System.out.println("Enter your Email Id :");
		while(true)
		{
			String n3=s.next();
			if(v.checkEmail(n3))
				break;
			System.out.println("Enter valid Email Id ...");
		}

	}

}
