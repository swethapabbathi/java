package com.capgemini.emp.ui;

import java.util.Random;
import java.util.Scanner;

import com.capgemini.emp.bean.Employee;
import com.capgemini.emp.dao.EmployeeDao;
import com.capgemini.emp.service.*;

public class Client {

	public static void main(String[] args)
	{
		System.out.println("Choose your choice: \n 1.Enter Employee Details:\n 2.Exit");
	  	Service s=new Service();
	  	Scanner obj=new Scanner(System.in);
	  	int n=obj.nextInt();
	  	if(n==1)
	  	{
	  		
	  		Employee e=new Employee("Ramesh","Manager",50000,"ramesh@gmail.com",767676676);
	  
	  	s.addEmployee(e);
	  	
	  	Random r=new Random();
	  int empid=r.nextInt(100);
	s.getEmployee(empid);
	  System.out.println("Employee has been successfully Register along with the ID :"+s.eid);
	  
	  EmployeeDao d=new EmployeeDao();
	  System.out.println("Travelling Allowance for the Employee is :"+d.CalculateTA(s.erole));
	  	}
	  	else
	  	{
	  		 System.out.println("closed");
	  	}
	}

}
