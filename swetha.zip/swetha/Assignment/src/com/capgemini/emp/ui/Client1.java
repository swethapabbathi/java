
package com.capgemini.emp.ui;

import java.util.Random;
import java.util.Scanner;
import java.util.regex.*;

import com.capgemini.emp.bean.Employee;
import com.capgemini.emp.dao.EmployeeDao;
import com.capgemini.emp.service.*;

public class Client1 {

	public static void main(String[] args)
	{
		System.out.println("Choose your choice: \n 1.Enter Employee Details:\n 2.Exit");
	  	Service s=new Service();
	  	Scanner m=new Scanner(System.in);
	  	int i=0;
	  	while(true)
	  	{
	  		System.out.println(" Enter name :");
		  	String n=m.next();
		  	boolean b=Pattern.matches("[A-Za-z]{5,}",n);
		  	if(b==true)
	  		{
	  			break;
	  		}
	  		else
	  		{
	  			System.out.println("Invalid Name, try again");
	  		}		
	  	}
	  	
	  		
	}

}
