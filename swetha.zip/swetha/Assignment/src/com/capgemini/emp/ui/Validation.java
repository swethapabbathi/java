package com.capgemini.emp.ui;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation 
{
	
	boolean checkPhoneno(String number)
	{
		/*Pattern p=Pattern.compile("[0-9]{2}");
		Matcher m=p.matcher(number);
		boolean b=m.matches();*/
		//return (m.find() && m.group().equals(number));
		boolean b=Pattern.matches("[0-9]{2}",number); 
		return b;	
	}
	boolean checkName(String name)
	{
		boolean b=Pattern.matches("[A-Z]{1}[a-z]{4,}",name); 
		return b;	
	}
	boolean checkPAN(String pan)
	{
		boolean b=Pattern.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}",pan); 
		return b;	
	}
	boolean checkEmail(String emailid)
	{
		boolean b=Pattern.matches("[A-Za-z0-9]{5,}[.]{1}[A-Za-z0-9]{3}[@]{1}[A-Za-z]{3}",emailid); 
		return b;	
	}
	boolean checkdob(String dob)
	{
		boolean b=Pattern.matches("[]",dob); 
		return b;	
	}
}
