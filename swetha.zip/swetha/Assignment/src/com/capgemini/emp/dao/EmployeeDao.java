package com.capgemini.emp.dao;

import com.capgemini.emp.bean.Employee;

interface IEmpDao
{
	double  CalculateTA(String role1);
}
public class EmployeeDao implements IEmpDao
{

	double sal=Employee.salary;
	public double CalculateTA(String role1) 
	{
		double output = 0;
		if(role1=="Senior Manager" )
			output=0.25*sal;
		else if(role1=="Manager")
			output=0.20*sal;
		else if(role1=="Senior Consultant")
			output=0.15*sal;
		else if(role1=="Consultant")
			output=0.10*sal;
		return output;
	}
	

}
