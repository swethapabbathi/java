package com.capgemini.emp.bean;

 public class Employee 
{
	   public static String name;
	   public static String role;
	   public static double salary;
	   public static  String mailid;
	   public static long phoneno;
	   public Employee(String name,String role,double salary,String mailid,long phoneno)
	   {
		   this.name=name;
		   this.role=role;
		   this.salary=salary;
		   this.mailid=mailid;
		this.phoneno=phoneno;
		   
	   }
	   
}
