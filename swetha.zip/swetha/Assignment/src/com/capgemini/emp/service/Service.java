package com.capgemini.emp.service;
import com.capgemini.emp.bean.*;

interface EmployeeService
{
	void addEmployee(Employee emp);
	Employee getEmployee(int empid);
}

public class Service implements EmployeeService
{
	
	public long eid;
	public String ename;
	public String erole;
	   public double esalary;
	   public  String emailid;
	   public long ephoneno;
	   
	public void addEmployee(Employee emp) 
	{
		ename=emp.name;
		erole=emp.role;
		esalary=emp.salary;
		emailid=emp.mailid;
		ephoneno=emp.phoneno;	
	}
	public Employee getEmployee(int empid) 
	{
		eid=empid;
		Employee emp1=new Employee(ename,erole,esalary, emailid,ephoneno);
		return emp1;
	}
	

	
}