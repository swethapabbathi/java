package com.cg.mobile.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.mobile.bean.Mobile;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.MobileServiceImpl;

public class MobileUI {
	
	public static void main(String[] args) {
		
		IMobileService service=new MobileServiceImpl();
		System.out.println(service.display()+"\n\n");
		Scanner sc = new Scanner(System.in);
		while(true){
			System.out.println("---------------------");
			System.out.println("\n\nI.	Insert");
			System.out.println("II.	Update");
			System.out.println("III.	View");
			System.out.println("IV.	Delete");
			System.out.println("V.	Search");
			System.out.println("VI.	Exit");
			System.out.println("Enetr your option");
			int opt = sc.nextInt();
			switch(opt){
			case 1: break;
			case 2: break;
			case 3: 
				List<Mobile> list2 = service.getAllMobileDetails();
				System.out.println("Mobiles for given cond are:");
				System.out.println("____________________________");
				for(Mobile m:list2){
					System.out.println("\nID:"+m.getMobileId());
					System.out.println("Name:"+m.getName());
					System.out.println("Price:"+m.getPrice());
					System.out.println("Quantity:"+m.getQuantity());
				}
				break;
			case 4:
				System.out.println("Mobile id");
				int mid=sc.nextInt();
				service.deleteByMobileId(mid);
				
				break;
			case 5: 
				System.out.print("Enter Price");
				double Price=sc.nextDouble();
				List<Mobile> list = service.getMobileByPrice(Price);
				System.out.println("Mobiles for given cond are:");
				System.out.println("____________________________");
				for(Mobile m:list){
					System.out.println("\nID:"+m.getMobileId());
					System.out.println("Name:"+m.getName());
					System.out.println("Price:"+m.getPrice());
					System.out.println("Quantity:"+m.getQuantity());
				}
				break;
			case 6: break;
			default: break;
			}
		}
	}

}
