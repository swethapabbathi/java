package com.cg.mobile.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.exception.MobileException;

public interface IMobileService 
{
	public String display();
	public List<Mobile> getMobileByPrice(double price);
	public List<Mobile> getAllMobileDetails();
	 public List<Mobile> deleteByMobileId(int mid);
	public boolean validateFileds(Customer customer) throws MobileException;
	public int store(Customer customer) throws NumberFormatException, ClassNotFoundException, SQLException ;
}
