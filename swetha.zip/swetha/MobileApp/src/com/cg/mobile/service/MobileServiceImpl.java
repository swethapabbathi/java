package com.cg.mobile.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.dao.IMobileDao;
import com.cg.mobile.dao.MobileDaoImpl;
import com.cg.mobile.exception.MobileException;

public class MobileServiceImpl implements IMobileService
{

	IMobileDao dao= new MobileDaoImpl();
	
	@Override
	public String display() 
	{
		return dao.display();
	}

	@Override
	public List<Mobile> getMobileByPrice(double price) {
		
		return dao.getMobileByPrice(price);
	}
	
	public List<Mobile> getAllMobileDetails()
	{
		return dao.getAllMobileDetails();
	}
	
	 public int deleteByMobileId(int mid)
	 {
		 return dao.deleteByMobileId(mid);
	 }
	 
	 public int storeDetails(Customer customer) throws MobileException, NumberFormatException, ClassNotFoundException, SQLException {
			return dao.store(customer);
		}

	 List<String> list = new ArrayList<String>();
	@Override
	public boolean validateFileds(Customer customer)  throws MobileException
	{

		boolean flag = false;

		if (!validateMobileId(customer.getMobileId())) {
			list.add("mobile should be 4 digits");
		}
		if (!validatePhoneno(customer.getPhoneno())) {
			list.add("phone no shoud be 10 digits and 1st digit is in [6-9]");
		}
		if (!validateName(customer.getCname())) {
			list.add("name length 6 to 20");
		}
		if (!validateMailid(customer.getMailid())) {
			list.add("4 chars and @ then 3 chars");
		}
		if (!validateQuantity(customer.getQuantity())) {
			list.add("enter less than the quantity available in mobile store");
		}

		if (!list.isEmpty()) {
			flag = false;
			throw new MobileException(list + "");
		} else {
			flag = true;
		}
		return flag;

	}
	public boolean validateMobileId(int mobileId) {
		String mobileRegEx = "[0-9]{4}";
		Pattern pattern = Pattern.compile(mobileRegEx);
		Matcher matcher = pattern.matcher(String.valueOf(mobileId));
		return matcher.matches();
	}
	
		public boolean validatePhoneno(String phoneno) {
		String mobileRegEx = "[6-9]{1}[0-9]{9}";
		Pattern pattern = Pattern.compile(mobileRegEx);
		Matcher matcher = pattern.matcher(String.valueOf( phoneno));
		return matcher.matches();
	}

	public boolean validateName(String name) {
		String nameRegEx = "[a-zA-Z]{6,20}";
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(name);
		return matcher.matches();
	}
	public boolean validateMailid(String mailid) {
		String nameRegEx = "[a-zA-Z]{4}[@]{1}[a-zA-Z]{3}";
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(mailid);
		return matcher.matches();
	}
	public boolean validateQuantity(String quantity) {
		String nameRegEx = "[1-9]{2}";
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(quantity);
		return matcher.matches();
	}

	@Override
	public int store(Customer customer) throws NumberFormatException, ClassNotFoundException, SQLException  {
			return dao.store(customer);
	
	}

}
