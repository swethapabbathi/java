package com.cg.mobile.bean;

import java.util.Date;

public class Customer 
{
	 private int purchaseId;
private String cname;
  private int mobileId;
  private String phoneno;
  private String mailid;
  private String quantity;
  private Date date; 
  
  
public Customer(String cname, int mobileId, String phoneno, String mailid, String quantity)
{
	super();
	this.cname = cname;
	this.mobileId = mobileId;
	this.phoneno = phoneno;
	this.mailid = mailid;
	this.quantity = quantity;
}

public int getPurchaseId() {
	return purchaseId;
}
public void setPurchaseId(int purchaseId) {
	this.purchaseId = purchaseId;
}
public int getMobileId() {
	return mobileId;
}
public void setMobileId(int mobileId) {
	this.mobileId = mobileId;
}
public String getQuantity() {
	return quantity;
}
public void setQuantity(String quantity) {
	this.quantity = quantity;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getPhoneno() {
	return phoneno;
}
public void setPhoneno(String phoneno) {
	this.phoneno = phoneno;
}
public String getMailid() {
	return mailid;
}
public void setMailid(String mailid) {
	this.mailid = mailid;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
  
}
