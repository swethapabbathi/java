package com.cg.mobile.dao;

public class QueryConstants {

	public static final String insertQuery = "insert into purchasedetails values(purchaseid2_sequence.nextval,?,?,?,?)";
	public static final String checkIdQuery = "select quantity from mobiles where mobileid=?";
	public static final String getId = "select max(id) from purchasedetails";
	public static final String updateQuery = "update mobiles set quantity=quantity-? where mobileid=?";
}
