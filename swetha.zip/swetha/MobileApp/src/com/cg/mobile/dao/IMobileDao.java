package com.cg.mobile.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;

public interface IMobileDao 
{
	public String display();
	public List<Mobile> getMobileByPrice(double price);
	public List<Mobile> getAllMobileDetails();
	public void deleteByMobileId(int mid);
	public int store(Customer customer) throws NumberFormatException, ClassNotFoundException, SQLException ;
}
