package com.cg.mobile.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.dao.QueryConstants;
import com.cg.mobile.exception.MobileException;

public class MobileDaoImpl implements IMobileDao
{
  public String display()
  {
	return "demo for mobile app";
  }
  public List<Mobile> getMobileByPrice(double price) 
  {
	  try
	  {
		  	Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			Connection con = DriverManager.getConnection (url, "system", "Capgemini123");
			//System.out.println("connected");
			String sql="select *from mobiles where price>=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setDouble(1,price);
			ResultSet rs=ps.executeQuery();
			Mobile m=null;
			List<Mobile> list=new ArrayList<>();
			while(rs.next())
			{
				m=new Mobile();
				m.setMobileId(rs.getInt(1));
				m.setName(rs.getString(2));
				m.setPrice(rs.getDouble(3));
				m.setQuantity(rs.getString(4));
				list.add(m);
			}
			return list;
	  }
	  catch(Exception e)
	  {}
	
	return null;
  }
  public List<Mobile> getAllMobileDetails()
  {
	  try
	  {
		  	Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			Connection con = DriverManager.getConnection (url, "system", "Capgemini123");
			//System.out.println("connected");
			String sql="select *from mobiles";
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			Mobile m=null;
			List<Mobile> list=new ArrayList<>();
			while(rs.next())
			{
				m=new Mobile();
				m.setMobileId(rs.getInt(1));
				m.setName(rs.getString(2));
				m.setPrice(rs.getDouble(3));
				m.setQuantity(rs.getString(4));
				list.add(m);
			}
			return list;
	  }
	  catch(Exception e)
	  {}
	
	return null;
  }
  public void deleteByMobileId(int mid)
  {
	  try
	  {
		  	Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			Connection con = DriverManager.getConnection (url, "system", "Capgemini123");
			String sql="delete from mobiles where mobileid=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1,mid);
			int rec=ps.executeUpdate();
			System.out.println(rec+ " recored deleted");
			
	  }
	  catch(Exception e)
	  {}
	
	
  }
@Override
public int store(Customer customer) throws NumberFormatException, ClassNotFoundException, SQLException 
{

		int quantity = Integer.parseInt(getQuantity(customer.getMobileId()));
		int id = 0;
		if (Integer.parseInt(customer.getQuantity())< quantity) {

			try {
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				String url = "jdbc:oracle:thin:@localhost:1521:XE";
				Connection con = DriverManager.getConnection (url, "system", "Capgemini123");
				PreparedStatement statement = null;
				
				statement = con.prepareStatement(QueryConstants.insertQuery);
				statement.setString(1, customer.getCname());
				statement.setString(2, customer.getMailid());
				statement.setString(3, customer.getPhoneno());
				statement.setLong(4, customer.getMobileId());
				

				statement.executeUpdate();

				id = getId();

				statement = con
						.prepareStatement(QueryConstants.updateQuery);
				statement.setString(1, customer.getQuantity());
				statement.setInt(2, customer.getMobileId());
				statement.executeUpdate();
			} catch (SQLException e) {
				//throw new MobileException("statement not created");
				e.printStackTrace();
			}
		}

		return id;
	}
public String getQuantity(int mobileId) throws ClassNotFoundException, SQLException  {

	Class.forName("oracle.jdbc.driver.OracleDriver");
	String url = "jdbc:oracle:thin:@localhost:1521:XE";
	Connection con = DriverManager.getConnection (url, "system", "Capgemini123");
	PreparedStatement statement = null;
	String quantity = null;
	try {

		statement = con.prepareStatement(QueryConstants.checkIdQuery);
		statement.setInt(1, mobileId);

		ResultSet resultSet = statement.executeQuery();

		resultSet.next();

		quantity = resultSet.getString(1);

	} catch (SQLException exception) {
		//throw new MobileException("statement not cretaed..");
		exception.printStackTrace();
	}
	return quantity;

}

public int getId() throws ClassNotFoundException, SQLException {

	Class.forName("oracle.jdbc.driver.OracleDriver");
	String url = "jdbc:oracle:thin:@localhost:1521:XE";
	Connection con = DriverManager.getConnection (url, "system", "Capgemini123");
	PreparedStatement statement = null;
	int id = 0;
	try {

		statement = con.prepareStatement(QueryConstants.getId);

		ResultSet resultSet = statement.executeQuery();

		resultSet.next();

		id = resultSet.getInt(1);

	} catch (SQLException exception) {
		//throw new MobileException("statement not cretaed..");
		exception.printStackTrace();
	}
	return id;

}
}
  

