package com.capgemini.ems.Service;

public class EmployeeServiceImpl implements EmployeeService
{

}
