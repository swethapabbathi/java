package com.capgemini.ems.Service;

public interface EmployeeService
{

}
