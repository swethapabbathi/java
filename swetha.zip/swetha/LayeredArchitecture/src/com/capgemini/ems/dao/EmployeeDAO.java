package com.capgemini.ems.dao;

public interface EmployeeDAO {

}
