package com.capgemini.ems.Presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.ems.DTO.Employee;
import com.capgemini.ems.Service.EmployeeService;
import com.capgemini.ems.Service.EmployeeServiceImpl;

public class EMSMain 
{

	public static void main(String[] args)
	{
		EmployeeService service =new EmployeeServiceImpl();
	
		System.out.println("Employee Management System");
		System.out.println("1. Add Employee");
		System.out.println("2.Exit");
		Scanner s=new Scanner(System.in);
		System.out.println("Select your choice");
		int option=0;
		try
		{
			option=s.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("Input should contain only digits");
			System.exit(0);
		}
		switch(option)
		{
		case 1:
			System.out.println("Enter ID: ");
			int id=s.nextInt();
			System.out.println("Enter name: ");
			String name=s.next();
			System.out.println("Enter salary: ");
			double salary=s.nextDouble();
			
			Employee employee =new Employee(id,name,salary);
			break;
		case 2:
			System.out.println("Thank u, visit Again");
			System.exit(0);
		default:
			System.out.println("Invalid input ,try again");
			break;
		}
		
	}

}
