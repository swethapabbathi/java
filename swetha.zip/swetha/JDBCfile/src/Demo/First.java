package Demo;
import java.sql.*;
public class First 
{
	public static void main(String a[])
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			Connection conn = DriverManager.getConnection (url, "system", "Capgemini123");
			System.out.println("connected");
			
			//ResultSet rs=st.executeQuery("SELECT FROM emp where empno=7902");
			
			
			String query = "INSERT INTO emp(empno,ename,job) VALUES(?,?,?)";
					PreparedStatement st=conn.prepareStatement(query);
					st.setInt(1,1004);
					st.setString(2, "swethaa");
					st.setString(3, "Manager");
					int rec = st.executeUpdate();
					System.out.println(rec + " record is inserted");
					
					Statement stmt=conn.createStatement();
					ResultSet rs=stmt.executeQuery("SELECT *FROM emp");
			while(rs.next())
			{
				System.out.println("Emo No = "+rs.getInt("empno"));
				System.out.println("Emo Name = "+rs.getString("ename"));
			}
					conn.close();
		}
		catch(Exception e)
		{
			System.out.println("Exception:"+e);
		}
	}
}