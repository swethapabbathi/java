package Demo;
import java.sql.*;
public class Second
{
	public static void main(String a[])
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			Connection conn = DriverManager.getConnection (url, "system", "Capgemini123");
			System.out.println("connected");
			
			//ResultSet rs=st.executeQuery("SELECT FROM emp where empno=7902");
			String query = " { call print(?, ?) } ";
			
			CallableStatement st = conn.prepareCall(query);
			st.setInt(1,103);
			st.registerOutParameter(2,java.sql.Types.VARCHAR);
			st.execute();
			String studName = st.getString(2);
			System.out.println(studName);

					conn.close();
		}
		catch(Exception e)
		{
			System.out.println("Exception:"+e);
		}
	}
}