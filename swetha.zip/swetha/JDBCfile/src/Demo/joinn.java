package Demo;

import java.util.Scanner;

public class joinn extends Thread
{
	static int n,sum;
	public static void main(String a[]) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter values");
		n=sc.nextInt();
		joinn j=new joinn();
		
		j.start();
		Thread.sleep(1000);
		//Thread.join();
		System.out.println("joinn sum is:"+ sum);
	}
	public void run()
	{
		System.out.println("run starts.......");
		long start =System.currentTimeMillis();
		for(int i=1;i<=n;i++)
		{
			sum=sum+i;
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception e)
			{	
			}
		}
		long end =System.currentTimeMillis();
		System.out.println("duration is:"+ (end-start)/1000);
		System.out.println("run ends..........");
	}
}
