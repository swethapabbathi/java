package Demo;

 class HelloThread1 extends Thread
{
	public void run()
	{
		System.out.println("hi");
	}
}
 class HelloThread2 implements Runnable
{
	public void run()
	{
		System.out.println("runnable");
	}
}
 public class HelloThread
{
	public static void main(String a[])
	{
		HelloThread1 h=new HelloThread1();
		h.start();
		HelloThread2 h1=new HelloThread2();
		Thread t =new Thread(h1);
		t.start();
	}
}