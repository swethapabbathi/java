package Lab7;
import java.util.*;
public class ArrayDemo 
{

	public static void main(String[] args)
	{
		  int n = 5; 
	       ArrayList<String> arrli = new ArrayList<String>(); 
	       Scanner m=new Scanner(System.in);
	       System.out.println("Enter strings :");
	       for (int i=0; i<=n; i++) 
	           arrli.add(m.next()); 
	      
	       Collections.sort(arrli);
	       for(String str:arrli)
	       {
	    	   System.out.println(str);
	       }
	 
	}
}


