package Lab7;

import java.util.*;
 class EmpDemo 
{
public  int id;

public   String name;

public  long salary;

public  String desig;

public String insuscheme;

	public EmpDemo()
	{}
	public  EmpDemo(int d, String n,long s, String desi)
	{
		id=d;
		name=n;
		salary=s;
		desig=desi;
	}
	static HashMap<String,EmpDemo>  hm= new HashMap<String,EmpDemo>();
	public void addEmployee(EmpDemo emp)
	{


EmpDemo ep1= new EmpDemo(101,"ifath",10000l,"associate");

EmpDemo ep2=new EmpDemo(102,"mani",20000l,"engineer");

EmpDemo ep3= new EmpDemo(103,"hashu",50000l,"analyst");

hm.put("e1",ep1);

hm.put("e2",ep2);

hm.put("e3",ep3);

}

public boolean deleteEmployee(int id) 

{
	
	hm.remove(EmpDemo.id);

return true;
}

public static void main(String args[])

{

EmpDemo emp=new EmpDemo();
emp.addEmployee(emp);

for(Map.Entry<String,EmpDemo> entry:hm.entrySet())

{  
        String key=entry.getKey();  

        EmpDemo b1=entry.getValue();  
        System.out.println(key+" Details:");  

        System.out.println(b1.id+" "+b1.name+" "+b1.salary+" "+b1.desig);   

}

 

/*emp.deleteEmployee(101);

System.out.println("hash map content after removing data:");

for(Map.Entry<String,EmpDemo> entry:hm.entrySet()) //for displaying the hm data after removing

{  

 

        String key=entry.getKey();  

        EmpDemo b1=entry.getValue();  

       

        System.out.println(key+" Details:");  

        System.out.println(b1.id+" "+b1.name+" "+b1.salary+" "+b1.desig);   

}
*/
 

}

 

}

 