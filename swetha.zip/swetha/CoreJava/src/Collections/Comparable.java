package Collections;
import java.util.*;  
import java.io.*;  
public class Comparable
{  
  public static void main(String args[])
  {  
	ArrayList<StudentCl> al=new ArrayList<StudentCl>();  
	al.add(new StudentCl(101,"Vijay",23));  
	al.add(new StudentCl(106,"Ajay",27));  
	al.add(new Student(105,"Jai",21));  
  
	Collections.sort(al);  
	for(StudentCl st:al)
	{  
		System.out.println(st.rollno+" "+st.name+" "+st.age);  
	}  
  }  
}  