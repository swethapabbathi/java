package Collections;

import java.util.HashSet;
import java.util.Iterator;



public class iterator 
{
	 public static void main(String args[]) 
	    { 
	        //create a Hashset to store strings 
	        HashSet<String> hs = new HashSet<String>() ; 
	  
	        // store some string elements 
	        hs.add("India"); 
	        hs.add ("America"); 
	        hs.add("Japan"); 
	  
	        for (String e: hs)
	            System.out.println(e);
	        System.out.println();  
	     // Iterating over collection 'c' using terator
	        for (Iterator i = hs.iterator(); i.hasNext(); ) 
	            System.out.println(i.next());
	        System.out.println();
	        // Add an Iterator to hs. 
	        Iterator it = hs.iterator(); 
	  
	        // Display element by element using Iterator 
	        while (it.hasNext()) 
	            System.out.println(it.next()); 
	    } 

}
