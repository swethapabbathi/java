package Collections;
import java.util.*;  
public class StudentCl implements Comparable<StudentCl>

{  
	int rollno;  
	String name;  
	int age;  
	StudentCl(int rollno,String name,int age)
	{  
		this.rollno=rollno;  
		this.name=name;  
		this.age=age;  
	}  
  
	public int compareTo(StudentCl st)
	{  
		if(age==st.age)  
			return 0;  
		else if(age>st.age)  
			return 1;  
		else  
			return -1;  
	}  
}  