package Collections;

public class Clonable implements Cloneable {

   private String name;

   public Clonable(String name) {

    this.name = name;

   }
   public String getName() {

    return name;
   }
   public static void main(String[] args) {

	   Clonable emp = new Clonable("Abhi");

    try {

        Clonable emp2 = (Clonable) emp.clone();

        System.out.println(emp2.getName());

    } catch (CloneNotSupportedException e) {

        System.out.println("not created"+e);

    }

   }

}

