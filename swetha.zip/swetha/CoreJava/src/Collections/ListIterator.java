package Collections;

import java.util.Vector;


//Java program to demonstrate working of ListIterator 
/*
 * ListIterator Interface: It is an interface that contains methods to retrieve the elements from a collection object,
 *  both in forward and reverse directions. This iterator is for list based collections.
It has following important methods:*/

public class ListIterator
{ 
 public static void main(String args[]) 
 { 
     // take a vector to store Integer objects 
     Vector<Integer> v = new Vector<Integer>(); 

     // Adding Elements to Vector 
     v.add(10); 
     v.add(20); 
     v.add(30); 

     // Creating a ListIterator 
     java.util.ListIterator<Integer> lit = v.listIterator(); 
     System.out.println("In Forward direction:"); 

     while (lit.hasNext()) 
         System.out.print(lit.next()+" ") ; 

     System.out.print("\n\nIn backward direction:\n") ; 
     while (lit.hasPrevious()) 
         System.out.print(lit.previous()+" "); 
 } 
} 