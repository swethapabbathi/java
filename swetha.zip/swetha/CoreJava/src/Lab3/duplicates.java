package Lab3;

public class duplicates {

	public static void main(String[] args) {
		String output1 = "munnimkfh";
        int count=0;int k=0;
        char[] strr=output1.toCharArray();
        int[] str1=new int[strr.length];
        char[] bob=new char[strr.length];
        
        	for(int i=0;i<strr.length;i++)
        	{
        		str1[i]=1;
        	}
        	
        for (int i = 0; i < strr.length; i++) 
        {
        	count=0;
            for (int j = i+1; j <strr.length; j++)
            {
                if (strr[i] == strr[j] && str1[j]!=0)
                {
                   count=count+1;
                   str1[j]=0;		           
                }
            }
           
          
            if(count<1 && str1[i]==1)
            {
            	bob[k]=strr[i];
            	System.out.println(bob[k]);
            	k++;
            }
            	
            
        }
	}

}
