package Lab3;

import java.time.ZoneId;

import java.time.ZonedDateTime;

 

public class ZoneIds {

	void zonedId(ZonedDateTime z,ZonedDateTime x,ZonedDateTime y)
	{
		  System.out.println("India:"+ z);
		  System.out.println("Paris:"+ x);
		  System.out.println("New York:"+ y);
	}
 

    public static void main(String[] args) {

         
          ZoneIds k=new ZoneIds();
         ZonedDateTime currentTime = ZonedDateTime.now();
        
         ZonedDateTime currentTimeInParis = ZonedDateTime.now(ZoneId.of("Europe/Paris"));
        ZonedDateTime currentTimeInNewYork = currentTime.withZoneSameInstant(ZoneId.of("America/New_York"));
       
        k.zonedId(currentTime, currentTimeInParis, currentTimeInNewYork);
         

         

    }

}