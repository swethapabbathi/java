package Lab3;
import java.util.*;



public class ArrayDemo 
{

	public static void main(String[] args)
	{
		  int n = 5; 
	       ArrayList<String> arrli = new ArrayList<String>(); 
	 
	     
	       for (int i=1; i<=n; i++) 
	           arrli.add("swe"); 
	 
	       // Printing elements 
		}	// TODO Auto-generated method stub

	}


