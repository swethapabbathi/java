package Lab3;

import java.util.Scanner;
import java.lang.String.*;

public class StringOperations
{
	public String Operations(String s,int m)
	{
		String output = null;
		int b=s.length();
		switch(m)
		{
			case 1:
				{
					output=s.concat(s);
				}
				break;
			case 2:
			{
				char[] strr=s.toCharArray();
				//String strr=s;
				for(int i=0;i<strr.length;i++)
				{
					if(i%2==1)
						strr[i]	='#';
				}
				String a=new String(strr);
				output=a;
				
			}
			 break;
			case 3:
			{
		        String output1 = s;
		        int count=0;int k=0;
		        char[] strr=s.toCharArray();
		        int[] str1=new int[strr.length];
		        char[] bob=new char[strr.length];
		        
		        	for(int i=0;i<strr.length;i++)
		        	{
		        		str1[i]=1;
		        	}
		        	
		        for (int i = 0; i < strr.length; i++) 
		        {
		        	count=0;
		            for (int j = i+1; j <strr.length; j++)
		            {
		                if (strr[i] == strr[j] && str1[j]!=0)
		                {
		                   count=count+1;
		                   str1[j]=0;		           
		                }
		            }
		            if(count<2 && str1[i]==1)
		            {
		            	bob[k]=strr[i];
		            	//System.out.println(bob[k]);
		            	k++;
		            }
		         }
		        String sr=new String(bob);	
		        output=sr;
			}
			break;
			case 4:
			{
				byte[] bytes=s.getBytes();
				for(int i=0;i<bytes.length;i++)
				{
					if(i%2==1 && bytes[i]>96 &&  bytes[i]<124)
					{
						bytes[i]-=32;
					}
					
				}
				String sr=new String(bytes);
				output=sr;
			}
		}
		return output;
	}
	public static void main(String[] args) 
	{
		System.out.println("Select your choice:\n 1.Add the String to itself\n 2.Replace odd positions with #\n 3.Remove duplicate characters in the String\n 4.Change odd characters to upper case");
		Scanner obj= new Scanner(System.in);
		int n=obj.nextInt();
		StringOperations st=new StringOperations();
		System.out.println(st.Operations("swethasath",n));

	}

}
