package Lab3;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Scanner;

public class PurchaseProductDate 
{
	void ExpireDate(LocalDate start,int warPeriodMonth,int warPeriodYear)
	{
		LocalDate ExpDate = start.plusYears(warPeriodYear);
		LocalDate ExpDate1 = ExpDate.plusMonths(warPeriodMonth);
		//LocalDate ExpDate1 = start.plus(pd);
		System.out.println("Your purchased product Expiry Date is :"+ExpDate1);
		
	}

	public static void main(String[] args) 
	{
		Scanner obj= new Scanner(System.in);
		System.out.println("enter the year:");
		int  year=obj.nextInt();
		System.out.println("enter month number:");
		int  month=obj.nextInt();
		System.out.println("enter day:");
		int  day=obj.nextInt();
		LocalDate start=LocalDate.of(year,month,day);
		
		System.out.println("enter the warrantee period year:");
		int warPeriodY=obj.nextInt();
		System.out.println("enter the warrantee period months:");
		int warPeriodM =obj.nextInt();
		//Period pd=Period.of(2,2,2); 
		
		 PurchaseProductDate x=new  PurchaseProductDate();
		 x.ExpireDate(start, warPeriodM, warPeriodY);
		LocalDate end=LocalDate.of(2018,Month.AUGUST,25);
		Period p=start.until(end);
		
		System.out.println(p.getDays());
		
		

	}

}
