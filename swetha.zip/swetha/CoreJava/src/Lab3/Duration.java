package Lab3;

public class Duration {

	public static void main(String[] args) 
	{
		

	}

}
