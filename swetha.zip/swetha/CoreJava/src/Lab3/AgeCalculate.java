package Lab3;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Scanner;

public class AgeCalculate
{
     String firstName,lastName;
     AgeCalculate( String firstName1,String lastName1)
     {
    	firstName= firstName1;
    	lastName=lastName1;
     }
    void setfirstName(String firstName )
     {
    	this.firstName=firstName;
     }
    String getfirstName()
    {
    	return firstName;
    }
    void setlastName(String lastName)
    {
   	this.lastName= lastName;
    }
    
    String getlastName()
     {
   		return lastName;
    }
    int CalculateAge(LocalDate dob)
    {
    	LocalDate end = LocalDate.now();
		Period p=dob.until(end);
		int output=p.getYears();
		return output;
    	
    }
    void display()
    {
    	System.out.println("Person Details:\n-------------------");
		System.out.println("First Name :"+getfirstName());
		System.out.println("Last Name :"+getlastName());
		
		
    }
	public static void main(String[] args) 
	{
		 AgeCalculate p=new  AgeCalculate("Swetha","Pabbathi");
		LocalDate dob = LocalDate.of(1996,Month.AUGUST,15);
		p.display();
		System.out.println("Age:"+p.CalculateAge(dob));
	}

}
