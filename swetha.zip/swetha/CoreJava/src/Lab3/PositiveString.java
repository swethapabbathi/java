package Lab3;

public class PositiveString
{
     void check(String k)
     {
    	 int lock=0;
    	 String str1=k.toLowerCase();
    	 char[] strr=str1.toCharArray();
    	 for(int i=1;i<strr.length;i++)
    	 {
    		 	int j=i-1;
				if(strr[j]<strr[i])
				{
					lock=0;
					continue;
				}
				else
				{
					lock=1;
					break;
				}
		}
    	 if(lock==0)
    		 System.out.println("It's a Positive");
    	 else
    		 System.out.println("It's not a Positive String");
     }

	public static void main(String[] args) 
	{
		PositiveString s=new PositiveString();
		s.check("Abc");
	}

}
