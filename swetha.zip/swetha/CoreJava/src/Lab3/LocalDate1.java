package Lab3;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class LocalDate1 
{
	void display(LocalDate start)
	{
		LocalDate end = LocalDate.now();
		Period p=start.until(end);
		System.out.println("Years: "+p.getYears());
		System.out.println("Months: "+p.getMonths());
		System.out.println("Days: "+p.getDays());
	}
	public static void main(String[] args) 
	{
		LocalDate1 s=new LocalDate1 ();
		   LocalDate start = LocalDate.of(1947,Month.AUGUST,15);
		  s.display(start);

	}

}
