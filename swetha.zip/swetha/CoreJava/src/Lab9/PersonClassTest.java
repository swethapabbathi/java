package Lab9;
import Lab.PersonClass;
import static org.junit.Assert.*;
import org.junit.Test;
public class PersonClassTest
{
	PersonClass p=new PersonClass("Swetha","Pabbathi",'F');
	@Test
	public void getFist()
	{
		assertEquals(p.getfirstName(),"Swetha");
	}
	@Test
	public void getLast()
	{
		assertEquals(p.getlastName(),"Pabbathi");
	}
	@Test
	public void getGen()
	{
		assertEquals(p.getGender(),'F');
	}
}
