package Lab9;
import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.eis.exception.*;
import com.cg.eis.bean.*;
import com.cg.eis.service.*;
public class ExceptionCheck 
{

	Employee emp=new Employee(101,"Shekhar","Manager",2000);
	EmployeeException e=new EmployeeException();
	String expected="The salary is less than 3000";
	@Test//(expected=EmployeeException.class)
	public void simpleAdd() 
	{
		
		assertEquals(EmployeeException.class,expected);
		
	}
}
