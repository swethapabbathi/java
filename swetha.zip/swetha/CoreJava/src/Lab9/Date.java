package Lab9;

class Date 
{
	int intintDay, intMonth, intYear;
	Date(int intDay, int intMonth, int intYear)  
	{
		this.intintDay = intDay;
		this.intMonth = intMonth;
		this.intYear = intYear;
	}
	void setDay(int intDay)	
	{
		this.intintDay = intDay;
	}
	int getDay( )		
   {
		return  this.intintDay;
   }

	void setMonth(int intMonth)
	{
		this.intMonth = intMonth;
	}

	int getMonth( )
	{
		return  this.intMonth;
	}

    void setYear(int intYear)
    {
    	this.intYear=intYear;
    }
    int getYear( )
    {
    	return  this.intYear;
    }
    public String toString() 
    {
    	return	"Date is "+intintDay+"/"+intMonth+"/"+intYear; 
    }
} 

