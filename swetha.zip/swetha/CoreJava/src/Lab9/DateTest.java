package Lab9;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
public class DateTest 
{
	Date d1=new Date(1,1,2018);
	@Before
	@Test 
	public void simpleAdd()
	{
		
		assertEquals(d1.toString(),"Date is 1/1/2018");
		
	}
	@Test 
	public void simpleDay()
	{
		//Date d1=new Date(1,1,2018);
		assertEquals(d1.getDay(),1);
	}
	@Ignore("hi")
	@Test 
	public void simpleMonth()
	{
		//Date d1=new Date(1,1,2018);
		assertEquals(d1.getMonth(),1);
	}
	@Test 
	public void simpleYear()
	{
		//Date d1=new Date(1,1,2018);
		assertEquals(d1.getYear(),2018);
	}
}
