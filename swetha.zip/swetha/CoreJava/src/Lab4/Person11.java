package Lab4;

class Account11
{
	long accNum;
	double balance=500;
	String accHolder;

	void setDeposit(double d)
	{
			balance+=d;
	}
	void getWithdraw(double w)
	{
		if(balance>=500)
			{
				balance-=w;
			}
		else
			System.out.println("Insufficient balance.");
	}
	double getBalance()
	{
		return balance;
	}

	void display()
	{
		System.out.println(accNum+" "+balance+" "+accHolder);
	}
}
class Person11 extends Account11
{
	String name;
	float age;
	Person11(long aNo, double bal, String aHo, float ag)
	{
		accNum=aNo;
		balance=bal;
		accHolder=aHo;
		age=ag;
	}
	public static void main(String[] args) 
	{
		Person11 a=new Person11(100001L,2000,"Smith",45);
		Person11 b=new Person11(100002L,3000,"Kethy",40);
		a.display();
		b.display();
		a.setDeposit(2000);
		b.getWithdraw(3000);
		a.getBalance();
		b.getBalance();
		System.out.println("\nUpdated BalanceSheet\n--------------------");
		a.display();
		b.display();
		//System.out.println(a.toString());
		//System.out.println(b.toString());
		}
}


