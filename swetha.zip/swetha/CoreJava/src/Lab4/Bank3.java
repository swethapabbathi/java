package Lab4;

class Acc 
{
	 long accNum;
	double balance=500;
	Acc(long a,double bal)
	{
		accNum=a;
		balance=balance+bal;
	}
	void setBalance(double b)
	{
		balance=balance+b;
	}
	
	  void deposit(float dep)
	  {
		  balance=balance+dep;
	  }
	  double withdraw(float wit)
	  {
		  balance=balance-wit;
		  return balance;
	  }
	  void getBalance()
	   {
		   System.out.println("your current balance is:"+ balance);
	   }
}

class SavingsAcc extends Acc
{
    final float minBal=1000;
	SavingsAcc(long a, double bal) 
	{
		super(a, bal);
	}
	 double withdraw(float wit)
	  {
		 if((super.balance-wit)>minBal)
		 {
			 super.balance=super.balance-wit;
			
			 //System.out.println("Your Savings Account Balance is :"+super.balance);
		 }
		 return super.balance;
	  }
	
}
/*class CurrentAcc extends Acc
{
	float  OverdraftLimit=100000;
 	CurrentAcc(long a, double bal) 
	{
		super(a, bal);
	}
 	
 	 double withdraw(float wit)
	  {
		 if(wit>OverdraftLimit)
		 {
			 System.out.println("You have reached your overdraft limit");
		 }
		 else
		 {
			 super.balance=super.balance-wit;
			 System.out.println("Your Savings Account Balance is :"+super.balance);
		 }
	  }
	
}*/

public class Bank3 
{

	public static void main(String[] args)
	{
		SavingsAcc a=new SavingsAcc(1,5000);
	//	a.setName("Smith");a.setAge(22);
		//a.getName();a.getAge();
		a.withdraw(4500);
		a.getBalance();

	}

}
