package Lab4;

class Savings extends A1
{

	
	A1 a=new A1();
	final static double bal=500;
	
	void withDraw(double d)
	{ 
	
		if(a.balance<=bal || d==a.balance)
		{
			System.out.println("Too low to withdraw");
	}
		else
		{
			 
			a.balance=a.balance-d;
			System.out.println(a.balance);
		}
	
	} 
}
public class Current
{
	
}



