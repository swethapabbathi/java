package Lab4;
import java.util.*;
class P1
{
	private String name;
private	float age;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	public String toString() {
return "Personname:" + getName();
		}
}
public class A1
{
	public long accNum;
	public double balance;
	P1 accHolder;
	public P1 getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(P1 accHolder) {
		this.accHolder = accHolder;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	void deposit(double d)
	{
		balance=balance+d;
	}
	void withDraw(double w)
	{
		balance=balance-w;
		
	}
	double getBal()
	{
		return balance;
	}
	public String toString() 
	{

        return  "Account Number:" +   accNum  + "\n accHolder: " +  getAccHolder().getName()+ " \nbalance: " + getBalance();
        }
public static void main(String[] args) {
		A1 accounts[]=new A1[100];
		Scanner sc=new Scanner(System.in);
		Savings s=new Savings();
	       
		int i=0;
		A1 ac = null;
        long accountNum = 0;
	while(true)
	{
		System.out.println("Create Account");
		System.out.println("Deposit");
		System.out.println("Withdarw");
		System.out.println("Check Balance");
		System.out.println("Exit");
	
	int choice=sc.nextInt();
	switch(choice)
	{
	case 1: 
		Random r=new Random();
	int n=r.nextInt(9999);
	System.out.println("Enter name of the accountant");
	P1 p=new P1();
	p.setName(sc.next());
	 ac=new A1();
	ac.setAccNum(n);
	ac.setAccHolder(p);
	System.out.println("Enter the initial balance");
	ac.setBalance(sc.nextDouble());
	accounts[i]=ac;
	i++;
	System.out.println(ac);
	System.out.println(p);
break;
	case 2:
		System.out.println("Enter the account number to deposit");
         accountNum=sc.nextLong();
         System.out.println("Enter the amount to deposit");
    double amount=sc.nextDouble();
    for(int k=0;k<i;k++)
    {
    	A1 a=accounts[k];
    if(a.accNum==accountNum)
    {
    	a.deposit(amount);
    }
    }
	break;
	
	case 3:
		System.out.println("Enter the account number to withdraw");
        accountNum=sc.nextLong();
        System.out.println("Enter the amount to withdraw");
       amount=sc.nextDouble();
       
   for(int j=0;j<i;j++)
   {
   	A1 a=accounts[j];
   if(a.getAccNum()==accountNum)
   {
	   s.withDraw(amount);
   	
   }
   }
	break;

	case 4:
		System.out.println("Enter the account number to view details");
        accountNum=sc.nextLong();
       for(int j=0;j<i;j++)
       {
    	   A1 a=accounts[j];
    	   if(a.getAccNum()==accountNum)
    	   {
    		   System.out.println(a.getBal());
    	   }
       }
       
       break;
	case 5:
			sc.close();
			System.exit(0);
		}
	}

}
}