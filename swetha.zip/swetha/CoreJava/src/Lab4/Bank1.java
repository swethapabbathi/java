package Lab4;
class Person1
{
	String name;
	float age;
	void setName(String n)
	{
		name=n;
	}
	void getName()
	{
		System.out.println(name);
	}
	void setAge(int a)
	{
		age=a;
	}
	void getAge()
	{
		System.out.println("Age :"+age);
	}
}

class Account1 extends Person1
{
	long accNum;
	double balance=500;
	Person1	accHolder;
	Account1(long a,double bal)
	{
		accNum=a;
		balance=balance+bal;
	}
	void setBalance(double b)
	{
		balance=balance+b;
	}
	  void getBalance()
	   {
		   System.out.println("your current balance is:"+balance);
	   }
	  void deposit(float dep)
	  {
		  balance=balance+dep;
	  }
	  void withdraw(float wit)
	  {
		  balance=balance-wit;
	  }
	  void setaccHolder()
	  {
		  this.accHolder=accHolder;
	  }
	  Person1 getaccHolder()
	  {
		  return accHolder;
	  }
	  
}
public class Bank1 
{

	public static void main(String[] args)
	{
		//Person p1=new Person();
		
		Account1 a=new Account1(1,2000);
		
		/*a.setName("Smith");a.setAge(22);
		a.getName();a.getAge();
		a.setBalance(2000);
		a.getBalance();
		
		//Person p2=new Person();
		Account1 a1=new Account1(2,3000);
		a1.setName("Kathy");a1.setAge(28);
		a1.getName();a1.getAge();
		
		a1.setBalance(2000);
		a1.getBalance();
		*/
	}

}
