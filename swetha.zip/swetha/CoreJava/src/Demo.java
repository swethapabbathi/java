class Animal 
{ 
	
}  
class Demo extends Animal
{  
  static void method(Animal a) 
  {  
     Demo d=(Demo)a;//downcasting  
       System.out.println("ok downcasting performed");  
  }  
   public static void main (String [] args) 
   {  
    Animal a=new Demo();  
   Demo.method(a);  
  }  
}  