package Lab6;
public class Exception1
{
	
	String firstName,lastName;
     char gender;
     public Exception1( String firstName1,String lastName1,char gender1)
     {
    	firstName= firstName1;
    	lastName=lastName1;
    	 gender= gender1;
     }
    void setfirstName(String firstName )
     {
    	this.firstName=firstName;
     }
    String getfirstName()
    {
    	return firstName;
    }
    void setlastName(String lastName)
    {
   	this.lastName= lastName;
    }
    
    String getlastName()
     {
   		return lastName;
    }
   
    void setGender(char gender)
    {
    		this.gender=gender;
    }
  char getGender()
  {
  	return gender;
  }
	public static void main(String[] args) 
	{
		Exception1 p=new Exception1("","",'F');
		try
		{
			if((p.getfirstName()=="") && (p.getlastName()==""))
			{
				throw new InvalidNameException();
				
			}
			else
			{
				System.out.println("Person Details:\n-------------------");
				System.out.println("First Name :"+p.getfirstName());
				System.out.println("Last Name :"+p.getlastName());
				System.out.println("Gender :"+p.getGender());
			}
		}
		catch(InvalidNameException i)
		{
			System.out.println("You didn't enter valid name "+i);
			i.invalid();
		}
		
		
	}

}
class InvalidNameException extends Exception
{
	void invalid()
	{
	System.out.println("Please enter valid name");
	}
}
