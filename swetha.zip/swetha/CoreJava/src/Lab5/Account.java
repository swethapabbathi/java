package Lab5;

 abstract class Account11
{
	long accNum;
	double balance=500;
	String accHolder;

	void setDeposit(double d)
	{
			balance+=d;
	}
	abstract void Withdraw(double w);
	double getBalance()
	{
		return balance;
	}

	void display()
	{
		System.out.println(accNum+" "+balance+" "+accHolder);
	}
}
class Account extends Account11
{
	String name;
	float age;
	Account(long aNo, double bal, String aHo, float ag)
	{
		accNum=aNo;
		balance=bal;
		accHolder=aHo;
		age=ag;
	}
	void Withdraw(double w)
	{
		if(balance>=500)
			{
				balance-=w;
			}
		else
			System.out.println("Insufficient balance.");
	}
	public static void main(String[] args) 
	{
		Account a=new Account(100001L,2000,"Smith",45);
		Account b=new Account(100002L,3000,"Kethy",40);
		a.display();
		b.display();
		a.setDeposit(2000);
		b.Withdraw(3000);
		a.getBalance();
		b.getBalance();
		System.out.println("\nUpdated BalanceSheet\n--------------------");
		a.display();
		b.display();
		//System.out.println(a.toString());
		//System.out.println(b.toString());
		}
}


