package Lab5;

abstract class bike
{
	abstract void run();
	void brake()
	{
		System.out.println("Testing the braking");
	}
	static void doi()
	{
		System.out.println("Testing the braking1");
	}
	
}

public class Abstr1 extends bike

{
	void run()
	{
		System.out.println("Testing the safely");
	}
	public static void main(String[] args)
	{
		bike obj= new Abstr1();
		obj.run();
		obj.brake();
		Abstr1.doi();

	}

}
