package Lab5;


interface bike1
{
	void run();
	void brake();
	static void brake1(){
		System.out.println("Testing static ");
	}
	
}

class Interface1 implements bike1

{
	public void run()
	{
		System.out.println("Testing the safely");
	}
	public void brake()
	{
		System.out.println("Testing the safely2...");
	}
	public static void main(String[] args)
	{
		 Interface1 obj=new  Interface1();
		obj.run();
		obj.brake();
		bike1.brake1();
	}

}
