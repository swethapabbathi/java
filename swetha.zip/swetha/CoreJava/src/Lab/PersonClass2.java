package Lab;

import java.util.Scanner;

public class PersonClass2
{
     String firstName,lastName;
     char gender;
     long phoneNumber;
     PersonClass2(){};
     PersonClass2( String firstName1,String lastName1,char gender1)
     {
    	firstName= firstName1;
    	lastName=lastName1;
    	 gender= gender1;
     }
    void setfirstName(String firstName )
     {
    	this.firstName=firstName;
     }
    String getfirstName()
    {
    	return firstName;
    }
    void setlastName(String lastName)
    {
   	this.lastName= lastName;
    }
    
    String getlastName()
     {
   		return lastName;
    }
   
    void setGender(char gender)
    {
    		this.gender=gender;
    }
    char getGender()
    {
    	return gender;
    }
    void setPhoneNumber(long number1)
    {
  		this.phoneNumber=number1;
    }
   long getphoneNumber()
    {
    	return phoneNumber;
    }
    void display()
    {
    	System.out.println("Person Details:\n-------------------");
		System.out.println("First Name :"+getfirstName());
		System.out.println("Last Name :"+getlastName());
		System.out.println("Gender :"+getGender());
		System.out.println("Phone Number :"+getphoneNumber());
		
    }
	public static void main(String[] args) 
	{
		PersonClass2 p=new PersonClass2("Swetha","Pabbathi",'F');
		System.out.println(" Enter a phone number:");
		Scanner obj= new Scanner(System.in);
		long number=obj.nextLong();
		p.setPhoneNumber(number);
		p.display();
	}

}
