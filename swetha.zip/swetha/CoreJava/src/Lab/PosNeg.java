package Lab;

import java.util.Scanner;

public class PosNeg {

	public static void main(String[] args)
	{
		/*System.out.println("Enter a number:");
		Scanner s=new Scanner(System.in);*/
		int k=Integer.parseInt(args[0]);
		if(k<0)
			System.out.println("negative number");
		else
			System.out.println("positive number");


	}

}
