package Lab;
import java.util.Scanner;
enum Gen 
{ 
    M,F; 
} 


public class PersonClassWEnum
{
     String firstName,lastName;
     Gen gender;
     long phoneNumber;
     PersonClassWEnum(){};
     PersonClassWEnum( String firstName1,String lastName1)
     {
    	firstName= firstName1;
    	lastName=lastName1;
    	
     }
    void setfirstName(String firstName )
     {
    	this.firstName=firstName;
     }
    String getfirstName()
    {
    	return firstName;
    }
    void setlastName(String lastName)
    {
   	this.lastName= lastName;
    }
    
    String getlastName()
     {
   		return lastName;
    }
   
    void setGender(Gen gender)
    {
    		this.gender=gender;
    }
    Gen getGender()
    {
    	return gender;
    }
    void setPhoneNumber(long number1)
    {
  		this.phoneNumber=number1;
    }
   long getphoneNumber()
    {
    	return phoneNumber;
    }
   
    void display()
    {
    	System.out.println("Person Details:\n-------------------");
		System.out.println("First Name :"+getfirstName());
		System.out.println("Last Name :"+getlastName());
		System.out.println("Gender :"+getGender());
		System.out.println("Phone Number :"+getphoneNumber());
		
    }
	public static void main(String[] args) 
	{
		Scanner obj= new Scanner(System.in);
		Gen c1 = Gen.M;
		Gen c2 = Gen.F;
		System.out.println("Select 1 for male 2 fro female");
		int c3=obj.nextInt();
		Gen c4;
		if(c3==1)
			c4=c1;
		else
			c4=c2;
		
		PersonClassWEnum p=new PersonClassWEnum("Swetha","Pabbathi");
		System.out.println(" Enter a phone number:");
		
		long number=obj.nextLong();
		p.setPhoneNumber(number);
		p.setGender(c4);
		p.display();
	}

}
