package Lab;

public class PersonClass
{
     String firstName,lastName;
     char gender;
     PersonClass(){};
     public PersonClass( String firstName1,String lastName1,char gender1)
     {
    	firstName= firstName1;
    	lastName=lastName1;
    	 gender= gender1;
     }
    void setfirstName(String firstName )
     {
    	this.firstName=firstName;
     }
    public String getfirstName()
    {
    	return firstName;
    }
    void setlastName(String lastName)
    {
   	this.lastName= lastName;
    }
    
    public String getlastName()
     {
   		return lastName;
    }
   
    void setGender(char gender)
    {
    		this.gender=gender;
    }
  public char getGender()
  {
  	return gender;
  }
	public static void main(String[] args) 
	{
		PersonClass p=new PersonClass("Swetha","Pabbathi",'F');
		System.out.println("Person Details:\n-------------------");
		System.out.println("First Name :"+p.getfirstName());
		System.out.println("Last Name :"+p.getlastName());
		System.out.println("Gender :"+p.getGender());
		
	}

}
