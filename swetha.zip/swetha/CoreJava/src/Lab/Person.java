package Lab;

public class Person {

	public static void main(String[] args)
	{
		System.out.println("Person Details:\n-------------------");
		System.out.println("First Name :Divya");
		System.out.println("Gender :F");
		System.out.println("Age :20");
		System.out.println("Weight :85.55");
	}

}
