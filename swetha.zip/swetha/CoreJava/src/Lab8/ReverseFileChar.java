package Lab8;

import java.io.*;

public class ReverseFileChar 
{
	public static void main(String[] args) throws IOException 
	{
		try
		{
			FileReader fr = new FileReader("D:\\swetha\\file1.txt");
			BufferedReader br=new BufferedReader(fr);
			FileWriter fw = new FileWriter("D:\\swetha\\file2.txt");
			BufferedWriter bw=new BufferedWriter(fw);
				int c;
				while ((c = br.read()) != -1) 
				{
					bw.write(c);
				}
		} 
		catch(IOException ex) 
		{
			System.out.println(ex.getMessage());
		}
	} 
}
