package Lab8;
import java.io.Serializable;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
 class MyClass7 implements Serializable 
{
    private static final long serialVersionUID = 1L;
    String street;
    String country;
    public void setStreet(String street) 
    {

         this.street = street;

    }
    public void setCountry(String country) 
    {

         this.country = country;

    }
    public String getStreet() 
    {

         return this.street;

    }
    public String getCountry() 
    {

         return this.country;

    }
    @Override

    public String toString() 
    {

         return new StringBuffer(" Street : ")

                 .append(this.street).append(" Country : ")

                 .append(this.country).toString();

    }
}

public class MyClass8 
{
    public static void main(String args[]) 
    {
         MyClass8 obj = new MyClass8();
         MyClass7 address = new MyClass7();
         address.setStreet("wall street");
         address.setCountry("united state");
         obj.serializeAddress(address);

    }

    public void serializeAddress(MyClass7 address) 
    {
         FileOutputStream fout = null;

         ObjectOutputStream oos = null;

         try {

             fout = new FileOutputStream("D:\\swetha\\Add.txt");

             oos = new ObjectOutputStream(fout);

             oos.writeObject(address);

             System.out.println("Done");

         } 
         catch (Exception ex)
         {

             ex.printStackTrace();
         } 
         finally
         {
             if (fout != null) 
             {
                 try
                 {
                      fout.close();
                 } 
                 catch (IOException e)
                 {
                      e.printStackTrace();

                 }

             }
             if (oos != null) 
             {
                 try
                 {
                      oos.close();

                 } 
                 catch (IOException e) 
                 {
                      e.printStackTrace();
                 }

             }

 

         }

    }

 

 /*   public void serializeAddressJDK7(MyClass7 address)
    {
         try (ObjectOutputStream oos = 

                 new ObjectOutputStream(new FileOutputStream("D:\\swetha\\Add.txt"))) 
                 {

 

             oos.writeObject(address);

             System.out.println("Done");

 

         } 
         catch (Exception ex) 
         {

             ex.printStackTrace();

         }

 

    }
*/
 
}
