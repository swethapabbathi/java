package Lab8;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;

public class ReadFileReverse {

public int[] readByte(File _file) throws IOException 
{
    FileInputStream source = new FileInputStream(_file);
    int currentByte = source.available();
    int readCount = 0;

    int byteContainer[] = new int[currentByte];
    while(readCount < currentByte){
        byteContainer[readCount] = source.read();
        readCount++;
    }
    source.close();
    return byteContainer;
}

public void printReverse(int[] fileContent, PrintWriter pwriter)
{
	
    for(int byt=fileContent.length -1; byt >= 0 ; byt--)
    {
    	pwriter.append((char) fileContent[byt]);
    }
}

public static void main(String[] args) throws IOException {
    File fileToRead = new File("D:\\swetha\\file1.txt");

    ReadFileReverse demo = new ReadFileReverse ();
    int[] readBytes = demo.readByte(fileToRead);
    PrintWriter pwriter =new PrintWriter("D:\\swetha\\file2.txt");
    demo.printReverse(readBytes,pwriter);
    pwriter.close();
}

}