package Lab8;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Numbers
{

	public static void main(String[] args) throws IOException 
	{
		File fileToRead = new File("D:\\swetha\\numbers.txt");
		 Scanner content=new Scanner(fileToRead); 
		 
            String s=content.nextLine();
            StringTokenizer st = new StringTokenizer(s,",");
            while (st.hasMoreTokens()) 
            {
	    	 int i=Integer.parseInt(st.nextToken());  
	    	 if(i%2==0)
	    		 System.out.println(i);
            

         }
	}
}