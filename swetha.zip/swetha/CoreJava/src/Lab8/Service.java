package Lab8;
import java.io.*;
class Employee implements Serializable
{
   public static int id;
   public static String name;
public static String designation;
public static String ischeme;
   public static double salary;
   public Employee(int id,String name,String designation,double salary)
   {
	   this.id=id;
	   this.name=name;
	   this.designation=designation;
	   this.salary=salary;
	   
   }
   
}
public class Service
{
	static FileOutputStream fos=null;
	static ObjectOutputStream oos=null;
	static FileInputStream fis=null;
	static ObjectInputStream ois=null;
	public static void main(String args[]) throws IOException, ClassNotFoundException
	{
		try
		{
			fos=new FileOutputStream("D:\\swetha\\Emp.txt");
			oos=new ObjectOutputStream(fos);
			Employee e=new Employee(101,"Swetha","Manager",50000);
			oos.writeObject(e);
			System.out.println("Serialized");
			
			fis=new FileInputStream("D:\\swetha\\Emp.txt");
			ois=new ObjectInputStream(fis);
			Employee obj=(Employee)ois.readObject();
			System.out.println("DeSerialized");
			
			System.out.println("Name :"+obj.name);
		}
		finally
		{
			if(fos!=null)
				fos.close();
			if(oos!=null)
				oos.close();
		}
	}
	
}
