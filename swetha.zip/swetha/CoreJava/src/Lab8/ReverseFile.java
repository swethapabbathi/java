package Lab8;

import java.io.*;
import java.util.Scanner;

public class ReverseFile
{
    public static void main(String[] args) throws IOException
       {
          try{
        
          File sourceFile=new File("D:\\swetha\\file1.txt");

          Scanner content=new Scanner(sourceFile); 
          PrintWriter pwriter =new PrintWriter("D:\\swetha\\file2.txt");

          while(content.hasNextLine())
          {
             String s=content.nextLine();
             StringBuffer buffer = new StringBuffer(s);
             buffer=buffer.reverse();
             String rs=buffer.toString();
             pwriter.println(rs);
          }
          content.close();    
          pwriter.close();
          System.out.println("File is copied successful!");
          }

          catch(Exception e){
              System.out.println("Something went wrong");
          }
       }
}