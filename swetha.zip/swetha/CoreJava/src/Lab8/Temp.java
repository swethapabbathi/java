package Lab8;

import java.util.*;

import java.io.*;

public class Temp 
{
	public static void main(String[] args)
	{
		Scanner input = null;
		try {

            input = new Scanner(new File("D:\\number.txt"));

        } 
		catch (Exception ex) 
		{

            ex.printStackTrace();

        }
        ArrayList<Integer> list=new ArrayList<Integer>();

       // int counter=evenCounter=0;

        while(input.hasNextInt()) {

            list.add(input.nextInt());
        }

        System.out.println(list);

      for(int i=0;i<list.size();i++)
      {
    	  if(list.get(i)%2==0)
    	  {
    		  System.out.println(list.get(i));
    	  }
      }

    }


}