package com.cg.operators;
 class Parent{
	String k="this is the parent";
}

public class ClassC extends Parent
{
		public void check()
		{
			System.out.println("Success");
			System.out.println(k);
		}
		public static void view(Parent c)
		{
			if(c instanceof ClassC)
			{
				ClassC b1=(ClassC) c;
				b1.check();
				
			}
		}
	public static void main(String[] args) 
	{
		Parent b=new ClassC();
		ClassC.view(b);
		//ClassC d=new ClassC();d.view(c);

	}
}