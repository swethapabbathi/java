package com.cg.operators;

public class Class2 {

	public static void main(String[] args) {
		
		int num1=12,num2=4;
		int sum= num1+num2;
		System.out.println("sum is:"+sum);
		int diff= num1-num2;
		System.out.println("difference is:"+diff);
		int mul= num1*num2;
		System.out.println("multiplied value is:"+mul);
		int div= num1/num2;
		System.out.println("quotient is:"+div);
		int rem= num1%num2;
		System.out.println("remender is:"+rem);
	}

}
