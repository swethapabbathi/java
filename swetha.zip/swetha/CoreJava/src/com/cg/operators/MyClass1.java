package com.cg.operators;

public class MyClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("this is my first java program");

	}

}
