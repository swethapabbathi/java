package com.cg.operators;

public class Conditional_op {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String out;
		int a=6,b=12;
		out = a==b? "Yes":"No";
		System.out.println("Ans:"+out);
	}

}
