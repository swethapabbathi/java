package com.cg.operators;

public class VarTypes {
	int k;//instance var
	static int m=6;//class var
	public void check()
	{
		int n=10;// local var
		System.out.println(n);
	}

	public static void main(String[] args) {
		
  VarTypes var=new VarTypes();
  var.k=50;
  var.check();
	}

}
