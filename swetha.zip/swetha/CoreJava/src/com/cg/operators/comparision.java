package com.cg.operators;

public class comparision {

	public static void main(String[] args) {
		int num1=12,num2=4;
		System.out.println(num1>num2);
		
		System.out.println(num1<num2);
		int m=10,n=10;
		System.out.println(m==n);
		
		System.out.println(m<=n);
		
		System.out.println(m>=n);

	}

}
