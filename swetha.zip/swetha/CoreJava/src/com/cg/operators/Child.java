package com.cg.operators;
 class Parent1
 {
	String k="this is the parent";
}

public class Child extends Parent1
{
		public void check()
		{
			System.out.println("Success");
			System.out.println(k);
		}
		public static void view(Child x)
		{
			if(x instanceof Child)
			{
			
				Child b1=x;
				b1.check();
				System.out.println("Success");
			
			}
		}
	public static void main(String[] args) 
	
	{
	Child b=new Child();
		Child.view(b);
		

	}
}