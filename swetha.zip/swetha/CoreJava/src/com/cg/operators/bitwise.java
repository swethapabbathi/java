package com.cg.operators;

public class bitwise {

	public static void main(String[] args) {
		int i=2,j=3;
		System.out.println("i|j :"+(i|j));//signed numbers
		System.out.println("i&j :"+(i&j));
		System.out.println("i^j :"+(i^j));
		System.out.println("~j :"+(~j));
		System.out.println("j<<i :"+(j<<i));
		System.out.println("j :"+(j));
		System.out.println("j>>2 :"+(j>>2));
		
		int k=-5;
		System.out.println("k>>>1 :"+(k>>>1));
	}

}
