package com.cg.operators;

public class Logical {

	public static void main(String[] args) {
		boolean num1=true,num2=false;
		System.out.println("num1 && num2 :"+(num1 && num2));
		System.out.println(" num1 || num2 :"+(num1 || num2));
		System.out.println(" !(num1 && num2) :"+!(num1 || num2));
	

	}

}
