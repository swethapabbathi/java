package com.cg.operators;

public class IncDec {

	public static void main(String[] args) {
		
		int r=6;
		System.out.println("post increment value is:"+ (r++));
		System.out.println("after post increment ,value is:"+ r);
		
		int p=5;
		System.out.println("pre increment value is:"+ (++p));
		System.out.println("after pre increment, value is:"+ p);
		
		int q=6;
		System.out.println("post decrement value is:"+ (q--));
		System.out.println("after post decrement ,value is:"+ q);
		
		int t=5;
		System.out.println("pre decrement value is:"+ (--t));
		System.out.println("after pre decrement, value is:"+ t);
		

	}

}
