package com.cg.operators;

public class DataTypes {

	public static void main(String[] args) {
		byte byteVar=5;
		short shortVar=20;
		int intVar=30;
		long longVar=60;
		float floatVar=20;
		double doubleVar=20.123;
		boolean booleanVar=true;
		char charVar='w';
		
		System.out.println("Value of byteVar is:"+byteVar);
		System.out.println("Value of shortVar is:"+shortVar);
		System.out.println("Value of intVar is:"+intVar);
		System.out.println("Value of var is:"+longVar);
		System.out.println("Value of var is:"+floatVar);
		System.out.println("Value of var is:"+doubleVar);
		System.out.println("Value of var is:"+booleanVar);
		System.out.println("Value of var is:"+charVar);
	}

}
