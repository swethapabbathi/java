package com.cg.operators;

public class ChainInt {

	public static void main(String[] args) {
		int a,b,c;
		a=b=c=100;
		System.out.println(a+" "+b+" "+c);
	}

}
