package com.cg.operators;

public class SelfInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int a=20;
		int b=1;
		b +=10;
		System.out.println(b);
		b-=10;
		System.out.println(b);
		int c=10;
		c*=10;
		System.out.println(c);
	}

}
