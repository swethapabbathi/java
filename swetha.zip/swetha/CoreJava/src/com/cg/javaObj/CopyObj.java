package com.cg.javaObj;

public class CopyObj
{
	int id;
	String st;
	CopyObj(int i,String s)
	{
		st=s;
		id=i;
	}
	CopyObj(CopyObj obj)
	{
		id=obj.id;
		st=obj.st;
	}
    void display()
    {
    	System.out.println(id);
		System.out.println(st);
    }
	public static void main(String[] args) 
	{
		CopyObj s1=new CopyObj(101,"Sweety");
		CopyObj s2=new CopyObj(s1);
		s1.display();
		s2.display();

	}

}
