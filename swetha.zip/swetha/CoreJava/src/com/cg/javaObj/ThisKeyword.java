package com.cg.javaObj;

public class ThisKeyword {
	
	ThisKeyword()
	{
		this(5);
		System.out.println("hello all");
	}
	ThisKeyword(int x)
	{
		System.out.println(x);
	}
	public static void main(String[] args) 
	{
		ThisKeyword obj=new ThisKeyword();	

	}

}
