package com.cg.javaObj;

public class Student
{
	int maths,phy;
	Student(int m,int p)
	{
		maths=m;
		phy=p;
	}
	void computeScores()
	{
		int total=(maths+phy)/2;
		if(total>=60)
			System.out.println("total score is :"+total+" , passed");
		else if(total<60)
			System.out.println("total score is :"+total+" , Failed");
		else
			System.out.println("Invalid input");
	}
	
	public static void main(String[] args) 
	{
		Student s=new Student(50,50);
		s.computeScores();
	}
}
