package com.cg.javaObj;

public class Account 
{
	int blnc=10000;
	int deposit(int d)
	{
		blnc=blnc+d;
		return blnc;
	}
	int withdraw(int w)
	{
		blnc=blnc-w;
		return blnc;
	}
	void checkBal()
	{
		System.out.println("Your current blnc is: "+blnc);

	}
	public static void main(String[] args)
	{
		Account ac=new Account();
		ac.deposit(3000);
		ac.checkBal();

	}

}
