package com.cg.javaObj;

public class student111 {

	int id ,rollno;
	String name;
	void insertRecord(int r,String n)
	{
		id=r;
		name=n;
	}
	void display()
	{
		System.out.println(id);
		System.out.println(name);
	}
}
