package com.cg.javaObj;

public class TestStudent1 {
	
		public static void main(String[] args) {
		// TODO Auto-generated method stub
	   	student111 s1=new student111();
		System.out.println(s1.id);
		System.out.println(s1.name);
		s1.insertRecord(101,"sw");
		s1.display();
	}

}
