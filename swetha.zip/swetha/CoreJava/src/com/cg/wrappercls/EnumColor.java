package com.cg.wrappercls;

public class EnumColor
{ 
    enum Color 
    { 
        RED, GREEN, BLUE; 
    } 
  
    // Driver method 
    public static void main(String[] args) 
    { 
        Color c1 = Color.RED; /*Every enum constant is always implicitly public static final. Since it is static, 
        we can access it by using enum Name. Since it is final, we can�t create child enums.*/
        System.out.println(c1); 
    } 
}