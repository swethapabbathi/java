package com.cg.wrappercls;

public class inttoInt {

}
