package com.cg.wrappercls;

public class ExplicitTC {

	public static void main(String[] args)
	{
		byte i=100;
		int b=i;
		System.out.println("b val is:"+b);//implicit tc
		int k=100;
		byte m=(byte)k;
		System.out.println("m val is:"+m);//explicit tc
		
		int k1=130;
		byte m1=(byte)k1;
		System.out.println("m1 val is:"+m1);
		
		int k2=1024;
		byte m2=(byte)k2;
		System.out.println("m2 val is:"+m2);

	}

}
