package com.cg.wrappercls;
import java.util.Scanner;

public class Delimeter
{

		public static void main(String[] args) 
		{
			// TODO Auto-generated method stub
			Scanner obj= new Scanner("1,2,3,4,5").useDelimiter(",");
			while (obj.hasNextInt())
			{
				int num=obj.nextInt();
				if(num%2==0)
				{
					System.out.println(num);
				}
			}
			obj.close();

		}

	}
