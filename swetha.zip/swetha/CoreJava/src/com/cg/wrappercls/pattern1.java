package com.cg.wrappercls;

public class pattern1 {

	public static void main(String[] args)
	{
		
			int k,temp=1;
			for(int line=1;line<=4;line++)
			{
				if(line%2==1)
				{
					k=temp;
					for(int i=1;i<=line;i++)
					{
						
						System.out.print(k+" ");
						k++;
						
					}
				
					temp=2*line+line;
					System.out.println();
				}
				else
				{
					k=temp;
					int var=temp;
					for(int j=1;j<=line;j++)
					{
						System.out.print(k+" ");k--;
						
					}
					System.out.println();
					temp=var+1;
					
				}
			}
	}

}
