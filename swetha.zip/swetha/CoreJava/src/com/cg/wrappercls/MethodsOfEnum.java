package com.cg.wrappercls;

//Java program to demonstrate working of values(), 
//ordinal() and valueOf() 
enum Color 
{ 
 RED, GREEN, BLUE; 
} 

public class MethodsOfEnum
{ 
 public static void main(String[] args) 
 {
     Color arr[] = Color.values(); // Calling values() 
     for (Color col : arr)   // enum with loop 
     { 
         
         System.out.println(col + " at index "+ col.ordinal()); // Calling ordinal() to find index 
         // of color. 
     } 

     // Using valueOf(). Returns an object of 
     // Color with given constant. 
     // Uncommenting second line causes exception 
     // IllegalArgumentException 
     System.out.println(Color.valueOf("RED")); 
     
     // System.out.println(Color.valueOf("WHITE")); 
 } 
} 