package com.cg.wrappercls;

import java.util.Scanner;

public class Scanner1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj= new Scanner(System.in);
		while (true)
		{
			System.out.println("Name");
			String in=obj.nextLine();
			if(in.isEmpty())
			{
				break;
			}
			
			
			
		}
		obj.close();

	}

}
