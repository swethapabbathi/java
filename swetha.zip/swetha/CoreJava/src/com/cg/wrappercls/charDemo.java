package com.cg.wrappercls;

import java.util.Scanner;

public class charDemo {

	public static void main(String[] args) 
	{
		int uppercount=0,lowercount=0;
		
		Scanner obj= new Scanner(System.in);
		System.out.println("enter name");
		String input=obj.nextLine();
			for(char ch:input.toCharArray())
			{
				if(!Character.isDigit(ch)&& Character.isAlphabetic(ch))
				{
					if(Character.isUpperCase(ch))
						uppercount++;
					else
						lowercount++;
				}
			}
			System.out.println("uppercount:"+uppercount);
			System.out.println("lowercount:"+lowercount);
		}
	}

