package com.cg.eis.service;
import com.cg.eis.bean.Employee;
import com.cg.eis.exception.*;

interface EmployeeService
{
	String ServicesOfferd();
}
public class Service implements EmployeeService
{
	
	double sal=Employee.salary;
	String role=Employee.designation;
	public String ServicesOfferd()
	{
		
		if((sal>5000 && sal<20000) && (role=="SystemAssociate"))
		{
			Employee.ischeme="Scheme C";
		}
		else if((sal>=40000) && (role=="Manager"))
		{
			Employee.ischeme="Scheme A";
		}
		else if((sal>=20000) && sal<40000 && (role=="Programmer"))
		{
			Employee.ischeme="Scheme B";
		}
		else if((sal<5000) && (role=="Clerk"))
		{
			Employee.ischeme="No Scheme";
		}
		else if((sal>3000) && sal<5000 )
		{
			Employee.ischeme=null;
		}
		else
		{
			try
			{
				throw new EmployeeException();		
			}
			catch(EmployeeException e)
			{
				System.out.println("Employee salary is < 3000, Please enter valid salary: "+e);
				e.show();
			}
		}
		return Employee.ischeme;
	
	}
}

