package com.cg.eis.pl;
import com.cg.eis.bean.*;
import java.util.HashMap;
import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl 
{
	public static void main(String args[])
	{
	 
		Scanner m = new Scanner(System.in);
		HashMap<String,Employee> map = new HashMap<String,Employee>();  
	//	map=init();
		for (String s:map.keySet())
		{
			System.out.println("Employee with id number:"+s+"is");
		}
		Employee[] e=new Employee[3];
				for(int i=0;i<5;i++)
				{
					
					list.put(m.next(),new Employee[i](m.nextInt(),m.next(),m.next(),m.nextInt()));
				}
	}
/*public void addEmp(Employee emp1)	
		{
			int id1;
		    String name1;
		    String designation1;
		    double salary1;
		  
			Scanner m= new Scanner(System.in);
			System.out.println("Enter id,name,desn,salary");
			id1=Employee.id;
			name1=Employee.name;
			designation1=Employee.designation;
			salary1=Employee.salary;
			
		}	
	/*public boolean deleteEmployee(int id)	
	{
		
	}*/
	
}
