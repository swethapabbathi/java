package com.cg.eis.pl;
import com.cg.eis.bean.Employee;
import com.cg.eis.service.*;

public class Test
{
	public static void main(String[] args) 
	{
	Employee emp=new Employee(101,"Shekhar","Manager",2000);
	Service i=new Service();
	System.out.println("Employee Details:\n-------------------");
	System.out.println("Name :"+emp.name);
	System.out.println("id: "+emp.id);
	System.out.println("Designition:"+emp.designation);
	System.out.println("Salary:"+emp.salary);
	//System.out.println("Insurance Scheme:"+emp.ischeme);
	System.out.println("Insurance Scheme:"+i.ServicesOfferd());
	

	}

}
