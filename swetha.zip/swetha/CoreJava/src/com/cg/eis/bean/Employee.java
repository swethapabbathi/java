package com.cg.eis.bean;

public class Employee 
{
   public static int id;
   public static String name;
public static String designation;
public static String ischeme;
   public static double salary;
   public Employee(int id,String name,String designation,double salary)
   {
	   this.id=id;
	   this.name=name;
	   this.designation=designation;
	   this.salary=salary;
	   
   }
   
}
