package com.cg.eis.exception;

public class EmployeeException extends Exception
{
	public String show() 
	
	{
		//System.out.println("The salary is less than 3000");
		return "The salary is less than 3000";
	}
}
