
public class SortStringArray 
{
	static String str[]={"Table","Chair","projector","book","Door"};
	public static void main(String args[])
	{
		for(int i=0;i<str.length;i++)
		{
			for(int j=i+1;j<str.length;j++)
			{
				if(((str[i]).toUpperCase()).compareTo((str[j]).toUpperCase())>0)
				{
					String temp=str[i];
					str[i]=str[j];
					str[j]=temp;
				}
			}
			System.out.println(str[i]);
		}
	}
}
