import org.apache.log4j.Logger;




public class HeadAche {

	public static void main(String[] args)
	{
		Logger l= Logger.getLogger(HeadAche.class.getName());
		l.error("hello");
	}

}
