package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.tcc.been.PatientBean;
import com.capgemini.tcc.exceptions.TakeCareException;
import com.capgemini.tcc.utility.JdbcUtility;

public class PatientDAO implements IPatientDAO {

	@Override
	public int addPatientDetails(PatientBean patient) throws TakeCareException 
	{
		Logger logger = Logger.getLogger(PatientDAO.class);

		Connection connection = null;
		PreparedStatement statement = null;

			int patientId = 0;

			connection = JdbcUtility.getConnection();

			

				try {
					statement = connection.prepareStatement(QueryConstants.insertQuery);
					statement.setString(1, patient.getPatientName());
					statement.setInt(2, patient.getAge());
					statement.setLong(3, patient.getPhone());
					statement.setString(4, patient.getDescription());
					statement.executeUpdate();

					statement = connection.prepareStatement(QueryConstants.getIdQuery);
					ResultSet resultSet = statement.executeQuery();
					resultSet.next();

					patientId = resultSet.getInt(1);

				} catch (SQLException e) {
					logger.error("statement not created..");
					throw new TakeCareException("statement not created");

				}


			return patientId;

	}

	@Override
	public PatientBean getPatientDetails(int patientId) throws TakeCareException {
		Logger logger = Logger.getLogger(PatientDAO.class);

		Connection connection = null;
		PreparedStatement statement = null;

			connection = JdbcUtility.getConnection();

		try
		  {
			  	
			statement = connection.prepareStatement(QueryConstants.selectQuery);
			statement.setInt(1,patientId);
				
				ResultSet rs=statement.executeQuery();
				PatientBean m=null;
				//List<PatientBean> list=new ArrayList<>();
				rs.next();
				
					m=new PatientBean();
					m.setPatientId(rs.getInt(1));
					m.setPatientName(rs.getString(2));
					m.setAge(rs.getInt(3));
					m.setPhone(rs.getLong(4));
					m.setDescription(rs.getString(5));
					m.setDate(rs.getDate(6));
					//list.add(m);
				return m;
		  }
		  catch(Exception e)
		  {}
		
		return null;
	  }
	
}


