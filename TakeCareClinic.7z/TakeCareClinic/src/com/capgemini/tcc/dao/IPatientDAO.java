package com.capgemini.tcc.dao;

import java.util.List;

import com.capgemini.tcc.been.PatientBean;
import com.capgemini.tcc.exceptions.TakeCareException;

public interface IPatientDAO {

	int addPatientDetails(PatientBean patient) throws TakeCareException;

	PatientBean getPatientDetails(int patientId)throws TakeCareException;

	

}
