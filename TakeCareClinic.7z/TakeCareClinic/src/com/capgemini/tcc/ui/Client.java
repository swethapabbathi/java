package com.capgemini.tcc.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.been.PatientBean;
import com.capgemini.tcc.exceptions.TakeCareException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client {
	static Logger logger = Logger.getLogger(Client.class);

	public static void main(String[] args) {

		PropertyConfigurator.configure("resources/log4j.properties");
		logger.info("log4j file loaded...");

		Scanner scanner = new Scanner(System.in);

		IPatientService service = new PatientService();

		System.out.println("welcome to  Health carew Application");
		System.out.println("1.fix appoinment");
		System.out.println("2.search");
		System.out.println("3.exit");

		System.out.println("Select ur choice");
		int choice = 0;
		try {
			choice = scanner.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("enter only digits");
			System.exit(0);
		}
		switch (choice) {
		case 1:
			scanner.nextLine();
			System.out.println("Enter name:");
			String name = scanner.nextLine();
			System.out.println("Enter MobileNumber:");
			long phone = 0;
			try {
				phone = scanner.nextLong();
			} catch (InputMismatchException e) {
				System.err.println("phone number should contain only digits");
				System.exit(0);
			}
			System.out.println("Enter patient Age:");
			int age = 0;
			try {
				age = scanner.nextInt();
			} catch (InputMismatchException e) {
				System.err.println("age should contain only digits");
				System.exit(0);
			}
			scanner.nextLine();
			System.out.println("problem Name");
			String problemName = scanner.nextLine();

			PatientBean patient = new PatientBean();
			patient.setPhone(phone);
			patient.setPatientName(name);
			patient.setAge(age);
			patient.setDescription(problemName);

			try {
				boolean result = service.validateDetails(patient);

				if (result) {
					int patientId = service.addPatientDetails(patient);
					System.out.println("ur appoiinment fixed with the id: " + patientId);
				}
				else
					System.exit(0);

			} catch (TakeCareException e) {
				System.err.println(e.getMessage());
			}

			break;
		case 2:
			System.out.print("Enter patient id :");
			int patientId=scanner.nextInt();
			PatientBean m;
			try {
				m = service.getPatientDetails(patientId);
				System.out.println("Patient details with given id: ");
				System.out.println("____________________________");
				
					System.out.println("\nID:"+ m.getPatientId());
					System.out.println("Name:"+m.getPatientName());
					System.out.println("Age:"+m.getAge());
					System.out.println("Mobile number:"+m.getPhone());
					System.out.println("Description:"+m.getDescription());
					System.out.println("Date:"+m.getDate());
			} catch (TakeCareException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			break;
		case 3:
			System.exit(0);
		default:System.out.println("closed");
			break;
		}

	}


}
