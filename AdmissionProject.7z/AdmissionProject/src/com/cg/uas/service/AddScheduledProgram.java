package com.cg.uas.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.uas.dao.UserDao;



/**
 * Servlet implementation class AddProgram
 */
@WebServlet("/AddProgram")
public class AddScheduledProgram extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String spid=request.getParameter("spid");
		String pname=request.getParameter("pname");
		String location=request.getParameter("location");
		String startdate=request.getParameter("startdate");
		String enddate=request.getParameter("enddate");
		String session=request.getParameter("session");
		
		System.out.println(startdate);
		UserDao dao=new UserDao();
		int n=0;
		try {
			n = dao.addProgram(spid,pname,location,startdate,enddate,session);
		
		if(n>0)
		{
			
			
			RequestDispatcher rd=request.getRequestDispatcher("admin.jsp?emsg=1 record added to the database");
			rd.forward(request, response);
		}
		else
		{	
		RequestDispatcher rd=request.getRequestDispatcher("admin.jsp?emsg= no record added to the database");
		rd.forward(request, response);
		}}
	catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
			
		
	


	}}
