package com.cg.saop;

import javax.jws.WebService;

@WebService(endpointInterface="com.cg.saop.HelloWorld")
public class HelloWorldImpl implements HelloWorld {
	@Override
	public String sayHello(){
		return "Hello,good afternoon";
	}

}
