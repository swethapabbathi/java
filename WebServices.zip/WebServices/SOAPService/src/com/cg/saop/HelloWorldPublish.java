package com.cg.saop;

import javax.xml.ws.Endpoint;

public class HelloWorldPublish {

	public static void main(String[] args) {
		
		Endpoint.publish("http://localhost:7871/hs", new HelloWorldImpl());
		
		
	}

}
