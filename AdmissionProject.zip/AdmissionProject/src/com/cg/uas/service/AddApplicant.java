package com.cg.uas.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.uas.dao.UserDao;

/**
 * Servlet implementation class AddApplicant
 */
@WebServlet("/AddApplicant")
public class AddApplicant extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String name=request.getParameter("name");
		String dob=request.getParameter("dob");
	
		String hq=request.getParameter("hq");
		String marks=request.getParameter("marks");
		String goals=request.getParameter("goals");
		String mail=request.getParameter("mail");
		String programid=request.getParameter("pid");

		
		
		UserDao dao=new UserDao();
		long n=dao.addApplicant(name,dob,hq,marks,goals,mail,programid);
		
		if(n>0)
		{
			out.println("<html><body><p> Application has been successfully registered with id: </p></body></html>"+n);
			//response.sendRedirect("login.jsp");
		}
		
	}

}
