package com.cg.uas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;

public class UserDao 
{
	Connection con=null;
	PreparedStatement ps=null;
	
	public Connection getConnection()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user="system";
			String pass="Capgemini123";
			con =DriverManager.getConnection(url,user,pass);
			return con;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
		
	}
	public boolean validate(String username ,String password)
	{
		try
		{
		con =getConnection();
		String sql="select *from Users where password=?";
		ps=con.prepareStatement(sql);
		ps.setString(1,password);
		ResultSet rs=ps.executeQuery();
		return rs.next();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
		
	}
	public int add(String username,String password,String role)
	{
		con =getConnection();
		String sql="insert into users values(?,?,?)";
		
		try
		{
			ps=con.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ps.setString(3, role);
		
			int n=ps.executeUpdate();
			return n;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
	}
	
	public int addProgram(String spid, String pname, String location,
			String startdate1, String enddate1, String session) {
		con =getConnection();
		String sql="insert into Programs_Scheduled values(?,?,?,?,?,?)";
		
		try
		{
			ps=con.prepareStatement(sql);
			ps.setString(1, spid);
			ps.setString(2, pname);
			ps.setString(3, location);
			String std[] = startdate1.split("-");
			int y = Integer.parseInt(std[0]);
			int m = Integer.parseInt(std[1]);
			int d = Integer.parseInt(std[2]);
			ps.setDate(4, new java.sql.Date(y, m, d));

			String std1[] = enddate1.split("-");
			int y1 = Integer.parseInt(std1[0]);
			int m1 = Integer.parseInt(std1[1]);
			int d1 = Integer.parseInt(std1[2]);
			ps.setDate(5, new java.sql.Date(y1, m1, d1));

			
			ps.setString(6, session);
		int n=ps.executeUpdate();
			return n;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
		
	}
	public int addProgramsOffered(String pname, String description,
			String eligibility, String duration, String certificate) {
		
		con =getConnection();
		String sql="insert into Programs_Offered values(?,?,?,?,?)";
		
		try
		{
			ps=con.prepareStatement(sql);
			ps.setString(1, pname);
			ps.setString(2, description);
			ps.setString(3, eligibility);
			ps.setString(4, duration);
			ps.setString(5, certificate);
			
		int n=ps.executeUpdate();
			return n;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	

}
